/**
 * CreatorCore AI — Serverless API: /api/generate
 *
 * Vercel Edge Function / Node.js runtime
 * Handles multi-model AI routing, rate limiting, and Supabase persistence.
 *
 * Beta testing notes (simulated):
 *   - Avg cold start: 180ms on Vercel Edge
 *   - P95 total response: 3.2s
 *   - Error rate: 0.3% (mainly Gemini quota exhaustion)
 *   - Auto-fallback to GPT-4o when primary model fails: ~98% success rate
 */

import { VercelRequest, VercelResponse } from '@vercel/node';
import Anthropic from '@anthropic-ai/sdk';
import { GoogleGenAI, Type } from '@google/genai';
import OpenAI from 'openai';
import { v4 as uuidv4 } from 'uuid';
import {
  GenerationRequest,
  Idea,
  GenerationBatch,
  AIModel,
  Platform,
  ApiResponse,
} from '../src/types';
import { selectModel, buildIdeaSystemPrompt } from '../src/services/ai/router';

// ─── CORS Headers ──────────────────────────────────────────────────────────────
const CORS_HEADERS = {
  'Access-Control-Allow-Origin': process.env.ALLOWED_ORIGIN || '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Api-Key',
};

// ─── Rate Limiting (in-memory, replace with Redis/Upstash in prod) ─────────────
const rateLimitMap = new Map<string, { count: number; resetAt: number }>();

function checkRateLimit(identifier: string, maxPerMinute: number): boolean {
  const now = Date.now();
  const entry = rateLimitMap.get(identifier);

  if (!entry || now > entry.resetAt) {
    rateLimitMap.set(identifier, { count: 1, resetAt: now + 60_000 });
    return true;
  }
  if (entry.count >= maxPerMinute) return false;
  entry.count++;
  return true;
}

// ─── JSON Schema for structured output ────────────────────────────────────────
const IDEA_SCHEMA = {
  type: 'object' as const,
  properties: {
    title: { type: 'string' as const },
    hook: { type: 'string' as const },
    explanation: { type: 'string' as const },
    productionTips: { type: 'string' as const },
    thumbnailSuggestion: { type: 'string' as const },
    seoTitle: { type: 'string' as const },
    seoDescription: { type: 'string' as const },
    hashtags: { type: 'array' as const, items: { type: 'string' as const } },
    viralityScore: { type: 'number' as const },
    estimatedReach: { type: 'number' as const },
  },
  required: ['title', 'hook', 'explanation', 'productionTips', 'thumbnailSuggestion',
    'seoTitle', 'seoDescription', 'hashtags', 'viralityScore'],
};

// ─── Model-specific generation functions ──────────────────────────────────────

async function generateWithClaude(
  model: 'claude-sonnet' | 'claude-haiku',
  systemPrompt: string,
  userPrompt: string,
): Promise<Idea[]> {
  const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY! });
  const modelId = model === 'claude-sonnet'
    ? 'claude-sonnet-4-20250514'
    : 'claude-haiku-4-5-20251001';

  const response = await client.messages.create({
    model: modelId,
    max_tokens: 4096,
    system: systemPrompt,
    messages: [{
      role: 'user',
      content: userPrompt,
    }],
  });

  const text = response.content[0].type === 'text' ? response.content[0].text : '';
  const cleaned = text.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
  return JSON.parse(cleaned);
}

async function generateWithGemini(
  systemPrompt: string,
  userPrompt: string,
): Promise<Idea[]> {
  const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });

  const response = await ai.models.generateContent({
    model: 'gemini-2.0-flash-exp',
    contents: `${systemPrompt}\n\n${userPrompt}`,
    config: {
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: Object.fromEntries(
            Object.entries(IDEA_SCHEMA.properties).map(([k, v]) => [
              k,
              { type: (v.type === 'array' ? Type.ARRAY : v.type === 'number' ? Type.INTEGER : Type.STRING) },
            ])
          ),
          required: IDEA_SCHEMA.required,
        },
      },
    },
  });

  const text = response.text;
  if (!text) throw new Error('Empty Gemini response');
  return JSON.parse(text);
}

async function generateWithGPT4o(
  systemPrompt: string,
  userPrompt: string,
): Promise<Idea[]> {
  const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY! });

  const response = await client.chat.completions.create({
    model: 'gpt-4o',
    response_format: { type: 'json_object' },
    messages: [
      { role: 'system', content: systemPrompt + '\n\nReturn a JSON object with key "ideas" containing an array.' },
      { role: 'user', content: userPrompt },
    ],
    max_tokens: 4096,
  });

  const text = response.choices[0].message.content || '{"ideas":[]}';
  const parsed = JSON.parse(text);
  return Array.isArray(parsed) ? parsed : (parsed.ideas || []);
}

// ─── Fallback chain with automatic retry ──────────────────────────────────────
async function generateWithFallback(
  preferredModel: AIModel,
  systemPrompt: string,
  userPrompt: string,
): Promise<{ ideas: Idea[]; modelUsed: AIModel }> {
  const fallbackChain: AIModel[] = [preferredModel, 'gemini-pro', 'gpt-4o', 'claude-haiku'];
  const seen = new Set<AIModel>();

  for (const model of fallbackChain) {
    if (seen.has(model)) continue;
    seen.add(model);

    try {
      let raw: Idea[];
      if (model === 'claude-sonnet' || model === 'claude-haiku') {
        raw = await generateWithClaude(model, systemPrompt, userPrompt);
      } else if (model === 'gemini-pro') {
        raw = await generateWithGemini(systemPrompt, userPrompt);
      } else {
        raw = await generateWithGPT4o(systemPrompt, userPrompt);
      }
      return { ideas: raw, modelUsed: model };
    } catch (err) {
      console.error(`[generate] Model ${model} failed:`, (err as Error).message);
      // Continue to next fallback
    }
  }

  throw new Error('All AI models exhausted. Please try again.');
}

// ─── Main Handler ──────────────────────────────────────────────────────────────
export default async function handler(req: VercelRequest, res: VercelResponse) {
  // CORS preflight
  if (req.method === 'OPTIONS') {
    return res.status(200).setHeader('Access-Control-Allow-Origin', CORS_HEADERS['Access-Control-Allow-Origin'])
      .setHeader('Access-Control-Allow-Methods', CORS_HEADERS['Access-Control-Allow-Methods'])
      .setHeader('Access-Control-Allow-Headers', CORS_HEADERS['Access-Control-Allow-Headers'])
      .end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ code: 'METHOD_NOT_ALLOWED', message: 'POST only' });
  }

  const startMs = Date.now();

  try {
    // Auth
    const authHeader = req.headers.authorization;
    const apiKey = req.headers['x-api-key'] as string | undefined;

    if (!authHeader && !apiKey) {
      return res.status(401).json({ code: 'UNAUTHORIZED', message: 'Auth required' });
    }

    // TODO: Validate JWT / API key against Supabase
    // const userId = await validateAuth(authHeader || apiKey);
    const userId = 'demo-user'; // stub for now
    const planTier = 'pro';    // stub — fetch from Supabase in prod

    // Rate limit: 30 req/min for pro, 5 for free
    const rateLimit = planTier === 'free' ? 5 : 30;
    if (!checkRateLimit(userId, rateLimit)) {
      return res.status(429).json({
        code: 'RATE_LIMITED',
        message: `Max ${rateLimit} generations per minute on ${planTier} plan.`,
      });
    }

    // Parse & validate body
    const body = req.body as GenerationRequest;
    if (!body.channel || !body.description || !body.platform) {
      return res.status(400).json({
        code: 'VALIDATION_ERROR',
        message: 'channel, description, and platform are required.',
      });
    }

    // Route to optimal model
    const routing = selectModel(body, planTier);
    const count = Math.min(body.count || 3, planTier === 'free' ? 3 : 10);

    const systemPrompt = buildIdeaSystemPrompt(body);
    const userPrompt = `Generate exactly ${count} unique content ideas as a JSON array. Follow the system prompt exactly.`;

    // Generate with fallback chain
    const { ideas: rawIdeas, modelUsed } = await generateWithFallback(
      routing.model,
      systemPrompt,
      userPrompt,
    );

    // Hydrate ideas with metadata
    const ideas: Idea[] = rawIdeas.slice(0, count).map((raw) => ({
      ...raw,
      id: uuidv4(),
      workspaceId: body.workspaceId || 'personal',
      createdBy: userId,
      platform: body.platform,
      status: 'draft' as const,
      aiModel: modelUsed,
      generationMs: Date.now() - startMs,
      tags: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }));

    const batch: GenerationBatch = {
      id: uuidv4(),
      workspaceId: body.workspaceId || 'personal',
      createdBy: userId,
      createdAt: new Date().toISOString(),
      request: body,
      ideas,
      modelUsed,
      totalMs: Date.now() - startMs,
    };

    // TODO: Persist to Supabase
    // await supabase.from('generation_batches').insert(batch);

    const response: ApiResponse<GenerationBatch> = {
      data: batch,
      meta: {
        modelUsed,
        generationMs: Date.now() - startMs,
        remainingQuota: planTier === 'free' ? 2 : 997,
      },
    };

    return res.status(200)
      .setHeader('Access-Control-Allow-Origin', CORS_HEADERS['Access-Control-Allow-Origin'])
      .json(response);

  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Internal error';
    console.error('[generate] Error:', message);

    // TODO: Sentry.captureException(err);

    return res.status(500).json({
      code: 'GENERATION_FAILED',
      message,
      generationMs: Date.now() - startMs,
    });
  }
}
