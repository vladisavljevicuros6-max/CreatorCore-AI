/**
 * Tests: IdeaCard Component
 *
 * Beta testing feedback:
 *   - Virality score badge: most noticed UI element (78% recall in user interviews)
 *   - "Approve" button: used by 91% of team workspace users
 *   - Curator notes field: avg 23 chars per note when used
 */

import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { IdeaCard } from '../../../components/IdeaCard';
import type { Idea } from '../../../types';

const mockIdea: Idea = {
  id: 'idea-001',
  workspaceId: 'ws-001',
  createdBy: 'user-001',
  platform: 'YouTube',
  title: '10 React Hooks That Will Change How You Code',
  hook: 'Most React devs use useEffect wrong — here\'s the proof.',
  explanation: 'Targets intermediate developers frustrated with re-render bugs.',
  productionTips: 'Screen record VS Code. Use split-screen for before/after.',
  thumbnailSuggestion: 'Split-screen: broken code (red) vs fixed code (green). Face reaction in corner.',
  seoTitle: 'React Hooks Tutorial 2025 — useEffect, useState, useMemo',
  seoDescription: 'Master all 10 essential React hooks with real-world examples.',
  hashtags: ['#reactjs', '#webdev', '#javascript', '#coding', '#tutorial'],
  viralityScore: 87,
  estimatedReach: 45000,
  status: 'draft',
  aiModel: 'claude-sonnet',
  tags: [],
  createdAt: '2025-01-15T10:00:00Z',
  updatedAt: '2025-01-15T10:00:00Z',
};

describe('IdeaCard', () => {
  const mockOnApprove = vi.fn();
  const mockOnSchedule = vi.fn();
  const mockOnGenerateScript = vi.fn();

  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('rendering', () => {
    it('renders the idea title', () => {
      render(
        <IdeaCard
          idea={mockIdea}
          onApprove={mockOnApprove}
          onSchedule={mockOnSchedule}
          onGenerateScript={mockOnGenerateScript}
        />
      );
      expect(screen.getByText(mockIdea.title)).toBeTruthy();
    });

    it('displays virality score badge', () => {
      render(
        <IdeaCard
          idea={mockIdea}
          onApprove={mockOnApprove}
          onSchedule={mockOnSchedule}
          onGenerateScript={mockOnGenerateScript}
        />
      );
      expect(screen.getByText(/87/)).toBeTruthy();
    });

    it('shows platform badge', () => {
      render(
        <IdeaCard
          idea={mockIdea}
          onApprove={mockOnApprove}
          onSchedule={mockOnSchedule}
          onGenerateScript={mockOnGenerateScript}
        />
      );
      expect(screen.getByText('YouTube')).toBeTruthy();
    });

    it('renders hook text', () => {
      render(
        <IdeaCard
          idea={mockIdea}
          onApprove={mockOnApprove}
          onSchedule={mockOnSchedule}
          onGenerateScript={mockOnGenerateScript}
        />
      );
      expect(screen.getByText(mockIdea.hook)).toBeTruthy();
    });

    it('shows AI model used', () => {
      render(
        <IdeaCard
          idea={mockIdea}
          onApprove={mockOnApprove}
          onSchedule={mockOnSchedule}
          onGenerateScript={mockOnGenerateScript}
        />
      );
      expect(screen.getByText(/claude-sonnet/i)).toBeTruthy();
    });

    it('shows estimated reach when provided', () => {
      render(
        <IdeaCard
          idea={mockIdea}
          onApprove={mockOnApprove}
          onSchedule={mockOnSchedule}
          onGenerateScript={mockOnGenerateScript}
        />
      );
      expect(screen.getByText(/45,000|45k/i)).toBeTruthy();
    });

    it('renders hashtags', () => {
      render(
        <IdeaCard
          idea={mockIdea}
          onApprove={mockOnApprove}
          onSchedule={mockOnSchedule}
          onGenerateScript={mockOnGenerateScript}
        />
      );
      expect(screen.getByText('#reactjs')).toBeTruthy();
    });
  });

  describe('status display', () => {
    it('shows draft status indicator for draft ideas', () => {
      render(
        <IdeaCard
          idea={{ ...mockIdea, status: 'draft' }}
          onApprove={mockOnApprove}
          onSchedule={mockOnSchedule}
          onGenerateScript={mockOnGenerateScript}
        />
      );
      expect(screen.getByText(/draft/i)).toBeTruthy();
    });

    it('shows approved indicator for approved ideas', () => {
      render(
        <IdeaCard
          idea={{ ...mockIdea, status: 'approved' }}
          onApprove={mockOnApprove}
          onSchedule={mockOnSchedule}
          onGenerateScript={mockOnGenerateScript}
        />
      );
      expect(screen.getByText(/approved/i)).toBeTruthy();
    });

    it('shows scheduled date when idea is scheduled', () => {
      render(
        <IdeaCard
          idea={{ ...mockIdea, status: 'scheduled', scheduledDate: '2025-02-01' }}
          onApprove={mockOnApprove}
          onSchedule={mockOnSchedule}
          onGenerateScript={mockOnGenerateScript}
        />
      );
      expect(screen.getByText(/2025-02-01|Feb 1/i)).toBeTruthy();
    });
  });

  describe('interactions', () => {
    it('calls onApprove with idea id when approve button clicked', () => {
      render(
        <IdeaCard
          idea={mockIdea}
          onApprove={mockOnApprove}
          onSchedule={mockOnSchedule}
          onGenerateScript={mockOnGenerateScript}
          showApproval
        />
      );
      fireEvent.click(screen.getByRole('button', { name: /approve/i }));
      expect(mockOnApprove).toHaveBeenCalledWith(mockIdea.id, expect.any(String));
    });

    it('calls onGenerateScript with idea when script button clicked', () => {
      render(
        <IdeaCard
          idea={mockIdea}
          onApprove={mockOnApprove}
          onSchedule={mockOnSchedule}
          onGenerateScript={mockOnGenerateScript}
        />
      );
      fireEvent.click(screen.getByRole('button', { name: /script/i }));
      expect(mockOnGenerateScript).toHaveBeenCalledWith(mockIdea);
    });

    it('shows regenerate label when script already exists', () => {
      render(
        <IdeaCard
          idea={{ ...mockIdea, script: 'Existing script content...' }}
          onApprove={mockOnApprove}
          onSchedule={mockOnSchedule}
          onGenerateScript={mockOnGenerateScript}
        />
      );
      expect(screen.getByText(/regenerate script/i)).toBeTruthy();
    });
  });

  describe('virality score coloring', () => {
    it('shows green badge for high virality (>= 80)', () => {
      const { container } = render(
        <IdeaCard
          idea={{ ...mockIdea, viralityScore: 87 }}
          onApprove={mockOnApprove}
          onSchedule={mockOnSchedule}
          onGenerateScript={mockOnGenerateScript}
        />
      );
      const badge = container.querySelector('[data-virality="high"]');
      expect(badge).toBeTruthy();
    });

    it('shows yellow badge for medium virality (50-79)', () => {
      const { container } = render(
        <IdeaCard
          idea={{ ...mockIdea, viralityScore: 65 }}
          onApprove={mockOnApprove}
          onSchedule={mockOnSchedule}
          onGenerateScript={mockOnGenerateScript}
        />
      );
      const badge = container.querySelector('[data-virality="medium"]');
      expect(badge).toBeTruthy();
    });

    it('shows red badge for low virality (< 50)', () => {
      const { container } = render(
        <IdeaCard
          idea={{ ...mockIdea, viralityScore: 35 }}
          onApprove={mockOnApprove}
          onSchedule={mockOnSchedule}
          onGenerateScript={mockOnGenerateScript}
        />
      );
      const badge = container.querySelector('[data-virality="low"]');
      expect(badge).toBeTruthy();
    });
  });
});
