/**
 * CreatorCore AI — Supabase Client
 *
 * Provides typed access to the Supabase Postgres database.
 * Tables: users, workspaces, workspace_members, generation_batches, ideas, api_keys
 *
 * Row-Level Security (RLS) is enforced at the DB level.
 * Users can only access their own workspace data.
 */

import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error(
    'Missing Supabase credentials. Set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY in .env'
  );
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  },
});

// ─── Auth Helpers ──────────────────────────────────────────────────────────────

export async function signInWithEmail(email: string, password: string) {
  const { data, error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) throw error;
  return data;
}

export async function signUpWithEmail(email: string, password: string, name: string) {
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: { data: { name } },
  });
  if (error) throw error;
  return data;
}

export async function signOut() {
  await supabase.auth.signOut();
}

export async function getSession() {
  const { data: { session } } = await supabase.auth.getSession();
  return session;
}

// ─── Data Helpers ──────────────────────────────────────────────────────────────

export async function getUserProfile(userId: string) {
  const { data, error } = await supabase
    .from('users')
    .select('*')
    .eq('id', userId)
    .single();
  if (error) throw error;
  return data;
}

export async function getWorkspaces(userId: string) {
  const { data, error } = await supabase
    .from('workspace_members')
    .select('workspace:workspaces(*)')
    .eq('user_id', userId);
  if (error) throw error;
  return data?.map((row: any) => row.workspace) || [];
}

export async function getBatches(workspaceId: string, limit = 20) {
  const { data, error } = await supabase
    .from('generation_batches')
    .select('*, ideas(*)')
    .eq('workspace_id', workspaceId)
    .order('created_at', { ascending: false })
    .limit(limit);
  if (error) throw error;
  return data || [];
}

export async function updateIdeaStatus(
  ideaId: string,
  status: string,
  notes?: string,
) {
  const { error } = await supabase
    .from('ideas')
    .update({ status, curator_notes: notes, updated_at: new Date().toISOString() })
    .eq('id', ideaId);
  if (error) throw error;
}

export async function scheduleIdea(ideaId: string, date: string) {
  const { error } = await supabase
    .from('ideas')
    .update({ scheduled_date: date, status: 'scheduled', updated_at: new Date().toISOString() })
    .eq('id', ideaId);
  if (error) throw error;
}
