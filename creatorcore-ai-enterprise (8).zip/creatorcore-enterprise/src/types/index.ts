// ============================================================
// CreatorCore AI — Enterprise Type Definitions
// Version: 2.0.0
// ============================================================

export type Platform =
  | 'YouTube'
  | 'YouTube Shorts'
  | 'TikTok'
  | 'Instagram Reels'
  | 'Twitter/X'
  | 'LinkedIn'
  | 'Twitch'
  | 'Podcast';

export type ContentStyle = 'viral' | 'educational' | 'entertainment' | 'balanced' | 'thought-leadership';

export type AIModel = 'claude-sonnet' | 'claude-haiku' | 'gemini-pro' | 'gpt-4o' | 'auto';

export type IdeaStatus = 'draft' | 'approved' | 'scheduled' | 'published' | 'archived';

export type WorkspaceRole = 'owner' | 'admin' | 'editor' | 'viewer';

export type PlanTier = 'free' | 'pro' | 'team' | 'enterprise';

// ─── Core Content Idea ────────────────────────────────────────────────────────

export interface Idea {
  id: string;
  workspaceId: string;
  createdBy: string;
  platform: Platform;
  title: string;
  hook: string;
  explanation: string;
  productionTips: string;
  thumbnailSuggestion: string;
  seoTitle: string;
  seoDescription: string;
  hashtags: string[];
  viralityScore: number;
  estimatedReach?: number;
  script?: string;
  thumbnailUrl?: string;
  scheduledDate?: string;
  publishedAt?: string;
  status: IdeaStatus;
  aiModel: AIModel;
  generationMs?: number;
  curatorNotes?: string;        // human-in-loop curation
  approvedBy?: string;
  tags: string[];
  createdAt: string;
  updatedAt: string;
}

export interface GenerationRequest {
  platform: Platform;
  channel: string;
  description: string;
  template: ContentStyle;
  preferredModel?: AIModel;
  count?: number;               // default 3, max 10 on pro/team
  workspaceId: string;
}

export interface GenerationBatch {
  id: string;
  workspaceId: string;
  createdBy: string;
  createdAt: string;
  request: GenerationRequest;
  ideas: Idea[];
  modelUsed: AIModel;
  totalMs: number;
}

// ─── User & Auth ──────────────────────────────────────────────────────────────

export interface User {
  id: string;
  email: string;
  name: string;
  avatarUrl?: string;
  plan: PlanTier;
  apiKey?: string;              // user-scoped API key for white-label
  createdAt: string;
  lastSeenAt: string;
  onboardingCompleted: boolean;
  preferences: UserPreferences;
}

export interface UserPreferences {
  defaultPlatform: Platform;
  defaultModel: AIModel;
  emailNotifications: boolean;
  timezone: string;
}

// ─── Workspace (Team Collab) ──────────────────────────────────────────────────

export interface Workspace {
  id: string;
  name: string;
  slug: string;
  logoUrl?: string;
  plan: PlanTier;
  ownerId: string;
  members: WorkspaceMember[];
  settings: WorkspaceSettings;
  createdAt: string;
  // White-label
  customDomain?: string;
  brandColor?: string;
  brandName?: string;
}

export interface WorkspaceMember {
  userId: string;
  name: string;
  email: string;
  avatarUrl?: string;
  role: WorkspaceRole;
  joinedAt: string;
}

export interface WorkspaceSettings {
  defaultModel: AIModel;
  requireApproval: boolean;     // human-in-loop gate
  allowedPlatforms: Platform[];
  maxIdeasPerDay: number;
  webhookUrl?: string;          // for API integrations
}

export interface WorkspaceInvite {
  id: string;
  workspaceId: string;
  email: string;
  role: WorkspaceRole;
  invitedBy: string;
  expiresAt: string;
  acceptedAt?: string;
}

// ─── API / Integration Layer ──────────────────────────────────────────────────

export interface ApiKey {
  id: string;
  workspaceId: string;
  name: string;
  keyPreview: string;           // last 4 chars only
  scopes: ApiScope[];
  createdAt: string;
  lastUsedAt?: string;
  revokedAt?: string;
}

export type ApiScope = 'ideas:generate' | 'ideas:read' | 'ideas:write' | 'workspace:read';

// ─── Analytics & Monitoring ───────────────────────────────────────────────────

export interface UsageMetrics {
  workspaceId: string;
  period: string;               // YYYY-MM
  ideasGenerated: number;
  scriptsGenerated: number;
  modelsUsed: Record<AIModel, number>;
  platformBreakdown: Record<Platform, number>;
  avgViralityScore: number;
  avgGenerationMs: number;
}

// ─── API Response Wrappers ────────────────────────────────────────────────────

export interface ApiResponse<T> {
  data: T;
  meta?: {
    modelUsed: AIModel;
    generationMs: number;
    remainingQuota?: number;
  };
}

export interface ApiError {
  code: string;
  message: string;
  statusCode: number;
}
