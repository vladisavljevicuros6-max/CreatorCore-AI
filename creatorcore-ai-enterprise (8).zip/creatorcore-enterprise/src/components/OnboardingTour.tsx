import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, ArrowRight, X, Zap, Users, BarChart3, Globe } from 'lucide-react';

interface OnboardingStep {
  title: string;
  description: string;
  icon: React.ReactNode;
  action?: string;
}

const STEPS: OnboardingStep[] = [
  {
    icon: <Sparkles className="w-8 h-8 text-indigo-400" />,
    title: 'Generate your first ideas',
    description: 'Enter your channel name, niche, and platform. Our AI router automatically selects the best model — Claude Sonnet for YouTube, Gemini Pro for TikTok.',
    action: 'Try it now →',
  },
  {
    icon: <Zap className="w-8 h-8 text-amber-400" />,
    title: 'One-click scripts',
    description: 'Love an idea? Hit "Write Script" and get a full production-ready script with B-roll cues, timing, and camera direction — in under 3 seconds.',
  },
  {
    icon: <Users className="w-8 h-8 text-emerald-400" />,
    title: 'Invite your team',
    description: 'Add editors and clients to your workspace. Curators can approve ideas, add notes, and schedule publishing — without touching a prompt.',
  },
  {
    icon: <BarChart3 className="w-8 h-8 text-blue-400" />,
    title: 'Track your calendar',
    description: 'Scheduled ideas appear in the content calendar. Connect your YouTube/TikTok account to publish directly (coming in v2.1).',
  },
  {
    icon: <Globe className="w-8 h-8 text-purple-400" />,
    title: 'White-label for agencies',
    description: 'On Enterprise, deploy CreatorCore under your own domain and brand. Your clients see your logo, not ours.',
  },
];

interface OnboardingTourProps {
  onComplete: () => void;
}

export function OnboardingTour({ onComplete }: OnboardingTourProps) {
  const [step, setStep] = useState(0);
  const isLast = step === STEPS.length - 1;
  const current = STEPS[step];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
    >
      <motion.div
        key={step}
        initial={{ opacity: 0, scale: 0.95, y: 10 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ duration: 0.25 }}
        className="bg-zinc-900 border border-zinc-700 rounded-2xl p-8 max-w-md w-full shadow-2xl"
      >
        {/* Close */}
        <button
          onClick={onComplete}
          className="absolute top-4 right-4 text-zinc-600 hover:text-zinc-300 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="space-y-5">
          {/* Icon */}
          <div className="w-16 h-16 rounded-2xl bg-zinc-800 border border-zinc-700 flex items-center justify-center">
            {current.icon}
          </div>

          {/* Content */}
          <div>
            <h2 className="text-xl font-bold text-white mb-2">{current.title}</h2>
            <p className="text-zinc-400 text-sm leading-relaxed">{current.description}</p>
          </div>

          {/* Progress dots */}
          <div className="flex gap-1.5">
            {STEPS.map((_, i) => (
              <div
                key={i}
                className={`h-1.5 rounded-full transition-all ${
                  i === step ? 'w-6 bg-indigo-500' : 'w-1.5 bg-zinc-700'
                }`}
              />
            ))}
          </div>

          {/* Actions */}
          <div className="flex items-center justify-between">
            <button
              onClick={onComplete}
              className="text-sm text-zinc-600 hover:text-zinc-400 transition-colors"
            >
              Skip tour
            </button>
            <button
              onClick={() => isLast ? onComplete() : setStep(step + 1)}
              className="flex items-center gap-2 px-5 py-2.5 bg-indigo-500 hover:bg-indigo-600
                text-white text-sm rounded-xl font-medium transition-colors"
            >
              {isLast ? 'Get started' : 'Next'}
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}
