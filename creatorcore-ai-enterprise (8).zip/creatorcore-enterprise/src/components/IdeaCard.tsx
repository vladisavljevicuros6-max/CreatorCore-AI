import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Video, Calendar, Check, ChevronDown, ChevronUp,
  Clock, Eye, Bot, Tag, ThumbsUp, Image, ExternalLink, Copy
} from 'lucide-react';
import { cn } from '../lib/utils';
import type { Idea, IdeaStatus } from '../types';

interface IdeaCardProps {
  idea: Idea;
  index?: number;
  onApprove?: (ideaId: string, notes: string) => void;
  onSchedule?: (ideaId: string) => void;
  onGenerateScript?: (idea: Idea) => void;
  isGeneratingScript?: boolean;
  showApproval?: boolean;
}

function ViralityBadge({ score }: { score: number }) {
  const tier = score >= 80 ? 'high' : score >= 50 ? 'medium' : 'low';
  const color = {
    high: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
    medium: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
    low: 'bg-red-500/10 text-red-400 border-red-500/20',
  }[tier];
  return (
    <div data-virality={tier} className={cn('flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold border whitespace-nowrap', color)}>
      🔥 {score}/100
    </div>
  );
}

function StatusBadge({ status }: { status: IdeaStatus }) {
  const config: Record<IdeaStatus, { label: string; class: string }> = {
    draft:     { label: 'Draft',       class: 'bg-zinc-800 text-zinc-400' },
    approved:  { label: 'Approved ✓',  class: 'bg-emerald-900/40 text-emerald-400' },
    scheduled: { label: 'Scheduled',   class: 'bg-blue-900/40 text-blue-400' },
    published: { label: 'Published',   class: 'bg-purple-900/40 text-purple-400' },
    archived:  { label: 'Archived',    class: 'bg-zinc-800 text-zinc-600' },
  };
  const cfg = config[status];
  return <span className={cn('px-2 py-0.5 rounded text-xs font-medium', cfg.class)}>{cfg.label}</span>;
}

// ─── Toast notification ───────────────────────────────────────────────────────
function Toast({ message, visible }: { message: string; visible: boolean }) {
  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ opacity: 0, y: 8, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 8, scale: 0.95 }}
          transition={{ duration: 0.18 }}
          className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 px-4 py-2.5
            bg-zinc-800 border border-zinc-700 rounded-full shadow-xl text-sm text-white font-medium"
        >
          <Check className="w-4 h-4 text-emerald-400" />
          {message}
        </motion.div>
      )}
    </AnimatePresence>
  );
}

export function IdeaCard({
  idea,
  index = 0,
  onApprove,
  onSchedule,
  onGenerateScript,
  isGeneratingScript = false,
  showApproval = false,
}: IdeaCardProps) {
  const [expanded, setExpanded] = useState(false);
  const [curatorNotes, setCuratorNotes] = useState(idea.curatorNotes || '');
  const [toastMsg, setToastMsg] = useState('');
  const [toastVisible, setToastVisible] = useState(false);

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setToastVisible(true);
    setTimeout(() => setToastVisible(false), 2500);
  };

  const formatReach = (n?: number) => {
    if (!n) return null;
    if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
    if (n >= 1_000) return `${(n / 1_000).toFixed(0)}K`;
    return n.toLocaleString();
  };

  const handleGenerateThumbnail = async () => {
    const prompt = `Create a highly engaging, click-worthy thumbnail for a ${idea.platform} video titled: "${idea.title}".

Concept: ${idea.explanation}

Thumbnail description: ${idea.thumbnailSuggestion}

Style requirements:
- High contrast, vibrant colors that pop in a feed
- Bold text overlay (3-5 words max)
- Expressive face or strong visual focal point
- Platform-optimized: ${idea.platform === 'YouTube' ? '16:9 ratio, 1280x720px' : idea.platform.includes('Short') || idea.platform === 'TikTok' || idea.platform === 'Instagram Reels' ? '9:16 ratio, 1080x1920px' : '16:9 ratio'}
- Emotional trigger: curiosity or urgency
- Make it impossible to scroll past`;

    try {
      await navigator.clipboard.writeText(prompt);
      showToast('Thumbnail prompt copied! Opening Gemini...');
      setTimeout(() => window.open('https://gemini.google.com', '_blank'), 600);
    } catch {
      // Clipboard blocked — show prompt in alert as fallback
      window.prompt('Copy this thumbnail prompt:', prompt);
    }
  };

  return (
    <>
      <Toast message={toastMsg} visible={toastVisible} />

      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: index * 0.08, duration: 0.3 }}
        className="bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden shadow-xl hover:border-zinc-700 transition-colors"
      >
        {/* Header */}
        <div className="p-6 space-y-4">
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1.5 flex-wrap">
                <span className="text-xs font-medium text-zinc-500 bg-zinc-800 px-2 py-0.5 rounded border border-zinc-700">
                  {idea.platform}
                </span>
                <StatusBadge status={idea.status} />
                {idea.scheduledDate && (
                  <span className="flex items-center gap-1 text-xs text-blue-400">
                    <Calendar className="w-3 h-3" />
                    {idea.scheduledDate}
                  </span>
                )}
              </div>
              <h3 className="text-base md:text-lg font-semibold text-white leading-tight">
                <span className="text-zinc-500 mr-2 text-sm">#{index + 1}</span>
                {idea.title}
              </h3>
            </div>
            <ViralityBadge score={idea.viralityScore} />
          </div>

          {/* Metrics */}
          <div className="flex items-center gap-4 text-xs text-zinc-500 flex-wrap">
            <span className="flex items-center gap-1">
              <Bot className="w-3 h-3" />
              {idea.aiModel}
            </span>
            {idea.estimatedReach && (
              <span className="flex items-center gap-1 text-zinc-400">
                <Eye className="w-3 h-3" />
                ~{formatReach(idea.estimatedReach)} reach
              </span>
            )}
            {idea.generationMs && (
              <span className="flex items-center gap-1">
                <Clock className="w-3 h-3" />
                {(idea.generationMs / 1000).toFixed(1)}s
              </span>
            )}
          </div>

          {/* Hook + Why it works */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div className="space-y-1">
              <span className="text-zinc-500 font-medium uppercase tracking-wider text-[10px]">Hook</span>
              <p className="text-zinc-300 leading-relaxed">{idea.hook}</p>
            </div>
            <div className="space-y-1">
              <span className="text-zinc-500 font-medium uppercase tracking-wider text-[10px]">Why it works</span>
              <p className="text-zinc-300 leading-relaxed">{idea.explanation}</p>
            </div>
          </div>

          {/* Expand toggle */}
          <button
            onClick={() => setExpanded((e) => !e)}
            className="flex items-center gap-1.5 text-xs text-zinc-500 hover:text-zinc-300 transition-colors"
          >
            {expanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            {expanded ? 'Hide details' : 'Production tips, SEO & hashtags'}
          </button>

          <AnimatePresence>
            {expanded && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="overflow-hidden space-y-4"
              >
                <div className="space-y-1 text-sm">
                  <span className="text-zinc-500 font-medium uppercase tracking-wider text-[10px]">Production Tips</span>
                  <p className="text-zinc-300">{idea.productionTips}</p>
                </div>

                <div className="space-y-1 text-sm">
                  <span className="text-zinc-500 font-medium uppercase tracking-wider text-[10px]">Thumbnail Concept</span>
                  <p className="text-zinc-300">{idea.thumbnailSuggestion}</p>
                </div>

                <div className="bg-black p-3.5 rounded-xl border border-zinc-800 text-sm space-y-1.5">
                  <span className="text-zinc-500 font-medium uppercase tracking-wider text-[10px]">SEO</span>
                  <p className="text-zinc-300"><span className="text-zinc-500">Title: </span>{idea.seoTitle}</p>
                  <p className="text-zinc-400 text-xs">{idea.seoDescription}</p>
                  <div className="flex flex-wrap gap-1.5 mt-2">
                    {idea.hashtags.map((tag) => (
                      <span key={tag} className="flex items-center gap-0.5 px-2 py-0.5 bg-zinc-800 text-zinc-400 rounded text-xs border border-zinc-700">
                        <Tag className="w-2.5 h-2.5" />{tag}
                      </span>
                    ))}
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Generated Script */}
          {idea.script && (
            <div className="mt-2 p-4 bg-indigo-500/5 border border-indigo-500/20 rounded-xl">
              <h4 className="text-sm font-semibold text-indigo-300 mb-2 flex items-center gap-2">
                <Video className="w-4 h-4" /> Script
                <span className="text-xs font-normal text-zinc-500 ml-auto">
                  {idea.script.split(/\s+/).length} words
                </span>
              </h4>
              <div className="text-sm text-zinc-300 whitespace-pre-wrap max-h-56 overflow-y-auto pr-1
                [scrollbar-width:thin] [scrollbar-color:theme(colors.zinc.700)_transparent]">
                {idea.script}
              </div>
            </div>
          )}

          {/* Curator Notes */}
          {showApproval && (
            <div className="space-y-2">
              <label className="text-[10px] font-medium text-zinc-500 uppercase tracking-wider">
                Curator Notes (optional)
              </label>
              <textarea
                value={curatorNotes}
                onChange={(e) => setCuratorNotes(e.target.value)}
                placeholder="Add feedback or direction for the creator..."
                rows={2}
                className="w-full bg-black border border-zinc-800 rounded-lg px-3 py-2 text-sm text-zinc-200
                  focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none resize-none transition-all"
              />
            </div>
          )}
        </div>

        {/* Actions Footer */}
        <div className="bg-black px-6 py-3 border-t border-zinc-800 flex flex-wrap items-center gap-2">

          {/* Write Script */}
          <button
            onClick={() => onGenerateScript?.(idea)}
            disabled={isGeneratingScript}
            className="flex items-center gap-2 px-3 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-200
              text-sm rounded-lg transition-colors border border-zinc-700 disabled:opacity-50"
          >
            {isGeneratingScript ? (
              <><span className="w-4 h-4 border-2 border-indigo-400 border-t-transparent rounded-full animate-spin" /> Writing...</>
            ) : (
              <><Video className="w-4 h-4 text-indigo-400" />{idea.script ? 'Regenerate Script' : 'Write Script'}</>
            )}
          </button>

          {/* Generate Thumbnail */}
          <button
            onClick={handleGenerateThumbnail}
            className="flex items-center gap-2 px-3 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-200
              text-sm rounded-lg transition-colors border border-zinc-700 group"
            title="Copies AI prompt then opens Gemini to generate thumbnail"
          >
            <Image className="w-4 h-4 text-emerald-400" />
            Gen Thumbnail
            <ExternalLink className="w-3 h-3 text-zinc-600 group-hover:text-zinc-400 transition-colors" />
          </button>

          {/* Approve */}
          {showApproval && idea.status === 'draft' && (
            <button
              onClick={() => onApprove?.(idea.id, curatorNotes)}
              className="flex items-center gap-2 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500
                text-white text-sm rounded-lg transition-colors font-medium"
            >
              <ThumbsUp className="w-4 h-4" />
              Approve
            </button>
          )}

          {/* Schedule */}
          <button
            onClick={() => onSchedule?.(idea.id)}
            className="flex items-center gap-2 px-3 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-200
              text-sm rounded-lg transition-colors border border-zinc-700 ml-auto"
          >
            {idea.status === 'scheduled'
              ? <><Check className="w-4 h-4 text-emerald-500" /> Scheduled</>
              : <><Calendar className="w-4 h-4 text-zinc-400" /> Schedule</>}
          </button>
        </div>
      </motion.div>
    </>
  );
}
