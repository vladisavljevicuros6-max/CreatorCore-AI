import { NavLink } from 'react-router';
import { LayoutDashboard, Calendar, User, Users, Sparkles } from 'lucide-react';
import { cn } from '../lib/utils';

interface SidebarProps {
  user?: { name: string; plan: string };
}

const PLAN_BADGE: Record<string, string> = {
  free: 'bg-zinc-700 text-zinc-400',
  pro: 'bg-indigo-500/20 text-indigo-300',
  team: 'bg-emerald-500/20 text-emerald-300',
  enterprise: 'bg-amber-500/20 text-amber-300',
};

export function Sidebar({ user }: SidebarProps) {
  const links = [
    { to: '/', icon: LayoutDashboard, label: 'Generate' },
    { to: '/calendar', icon: Calendar, label: 'Calendar' },
    { to: '/workspace', icon: Users, label: 'Workspace' },
    { to: '/profile', icon: User, label: 'Account' },
  ];

  return (
    <>
      {/* Desktop Sidebar */}
      <aside className="hidden md:flex w-64 bg-black border-r border-zinc-800 h-screen sticky top-0 flex-col">
        <div className="p-5 border-b border-zinc-800 flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-indigo-500 flex items-center justify-center">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="font-bold text-base text-white tracking-tight">CreatorCore</h1>
            <p className="text-[10px] text-zinc-500">AI Content Platform</p>
          </div>
        </div>

        <nav className="flex-1 p-3 space-y-0.5">
          {links.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              end={link.to === '/'}
              className={({ isActive }) =>
                cn(
                  'flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors',
                  isActive
                    ? 'bg-zinc-800 text-white'
                    : 'text-zinc-400 hover:text-white hover:bg-zinc-900',
                )
              }
            >
              <link.icon className="w-4 h-4" />
              {link.label}
            </NavLink>
          ))}
        </nav>

        {user && (
          <div className="p-4 border-t border-zinc-800">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-full bg-zinc-700 flex items-center justify-center text-xs font-bold text-white">
                {user.name[0]}
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-xs font-medium text-zinc-200 truncate">{user.name}</div>
                <span className={cn(
                  'text-[10px] font-semibold px-1.5 py-0.5 rounded uppercase tracking-wider',
                  PLAN_BADGE[user.plan] || PLAN_BADGE.free,
                )}>
                  {user.plan}
                </span>
              </div>
            </div>
          </div>
        )}
      </aside>

      {/* Mobile Bottom Nav */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-black border-t border-zinc-800 px-4 py-2 flex justify-around items-center z-50">
        {links.map((link) => (
          <NavLink
            key={link.to}
            to={link.to}
            end={link.to === '/'}
            className={({ isActive }) =>
              cn(
                'flex flex-col items-center gap-0.5 text-[10px] font-medium transition-colors py-1 px-2',
                isActive ? 'text-white' : 'text-zinc-500',
              )
            }
          >
            <link.icon className="w-5 h-5" />
            {link.label}
          </NavLink>
        ))}
      </nav>
    </>
  );
}
