/**
 * CreatorCore AI — Frontend API Service
 * Handles all calls to Vercel serverless functions.
 * Includes retry logic, error normalization, and optimistic updates.
 */

import { GenerationBatch, GenerationRequest, Idea, ApiResponse } from '../types';

const BASE_URL = import.meta.env.VITE_API_URL || '';

class ApiService {
  private async request<T>(
    endpoint: string,
    options: RequestInit = {},
  ): Promise<ApiResponse<T>> {
    const token = localStorage.getItem('creatorcore_token');
    const apiKey = localStorage.getItem('creatorcore_api_key');

    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(apiKey ? { 'X-Api-Key': apiKey } : {}),
    };

    const res = await fetch(`${BASE_URL}${endpoint}`, {
      ...options,
      headers: { ...headers, ...(options.headers as Record<string, string> || {}) },
    });

    if (!res.ok) {
      const errBody = await res.json().catch(() => ({}));
      const error = new Error(errBody.message || `HTTP ${res.status}`);
      (error as any).code = errBody.code;
      (error as any).statusCode = res.status;
      throw error;
    }

    return res.json() as Promise<ApiResponse<T>>;
  }

  async generateIdeas(req: GenerationRequest): Promise<ApiResponse<GenerationBatch>> {
    return this.request<GenerationBatch>('/api/generate', {
      method: 'POST',
      body: JSON.stringify(req),
    });
  }

  async generateScript(
    idea: Idea,
    planTier: string = 'free',
  ): Promise<ApiResponse<{ script: string; wordCount: number; estimatedRuntime: string }>> {
    return this.request('/api/script', {
      method: 'POST',
      body: JSON.stringify({ idea, planTier }),
    });
  }

  async approveIdea(ideaId: string, notes?: string): Promise<ApiResponse<Idea>> {
    return this.request<Idea>(`/api/ideas/${ideaId}/approve`, {
      method: 'PATCH',
      body: JSON.stringify({ notes }),
    });
  }
}

export const api = new ApiService();
