/**
 * geminiClient.ts
 * ─────────────────────────────────────────────────────────────────────────────
 * Browser-compatible Gemini API client — no SDK, pure fetch.
 *
 * Free-tier model priority (as of March 2026, post-Dec-2025 quota cuts):
 *   1. gemini-2.5-flash-lite   → 15 RPM, 1 000 RPD  ← highest throughput
 *   2. gemini-2.5-flash        → 10 RPM,   500 RPD  ← best quality / RPM balance
 *   3. gemini-2.0-flash        →  5 RPM,   (lower)  ← legacy fallback only
 *
 * Answers to your five questions are inline as comments throughout this file.
 */

// ─── Q4: v1 vs v1beta ────────────────────────────────────────────────────────
// Use v1beta. It exposes every current feature (structured output,
// system instructions, thinking config, grounding, etc.).
// v1 is the "stable" surface but lags behind; Google's own docs, AI Studio,
// and all official SDK code examples use v1beta for browser/AI-Studio-key flows.
// ─────────────────────────────────────────────────────────────────────────────
const GEMINI_BASE = 'https://generativelanguage.googleapis.com/v1beta/models';

// ─── Q1 + Q2: Model list and RPM limits ──────────────────────────────────────
// Free-tier limits per project (not per key) — post-Dec-2025 values.
// RPM = rolling 60 s window. RPD resets midnight Pacific.
// You CANNOT call ListModels to get RPM values — that endpoint only returns
// capabilities (input/output modalities, token limits), NOT quota numbers.
// RPM quotas live in your AI Studio project dashboard, not in the API response.
//
// To call ListModels yourself (returns capabilities, not RPM):
//   GET https://generativelanguage.googleapis.com/v1beta/models?key=YOUR_KEY
//
// Current free-tier RPM reference table:
//   gemini-2.5-flash-lite   15 RPM  1 000 RPD  250 K TPM
//   gemini-2.5-flash        10 RPM    500 RPD  250 K TPM
//   gemini-2.0-flash         5 RPM    ~20 RPD  250 K TPM  ← severely cut Dec-2025
//   gemini-2.5-pro           5 RPM    100 RPD  250 K TPM
// ─────────────────────────────────────────────────────────────────────────────

export interface GeminiModel {
  name: string;
  rpmFree: number;
  rpdFree: number;
}

// Ordered highest → lowest free-tier RPM. The fallback chain tries them in order.
export const GEMINI_FREE_MODELS: GeminiModel[] = [
  { name: 'gemini-2.5-flash-lite', rpmFree: 15, rpdFree: 1000 },
  { name: 'gemini-2.5-flash',      rpmFree: 10, rpdFree: 500  },
  { name: 'gemini-2.0-flash',      rpmFree: 5,  rpdFree: 20   }, // legacy, keep as last resort
];

// ─── Q3: responseMimeType: 'application/json' ─────────────────────────────────
// Supported on ALL main free-tier text models (2.5-flash-lite, 2.5-flash,
// 2.0-flash, 2.5-pro). It is NOT supported on:
//   • Embedding models (text-embedding-*, embedding-001)
//   • Audio/image-generation-only models (Imagen, native audio)
// Using it on an unsupported model returns HTTP 400 with:
//   "responseMimeType is not supported for this model."
// Safe rule: if the model name contains "flash" or "pro" (text generation),
// you're fine. Never send it to embedding or imagen models.
// ─────────────────────────────────────────────────────────────────────────────

// ─── Types ────────────────────────────────────────────────────────────────────

export interface GeminiRequestOptions {
  /** Your AI-Studio API key */
  apiKey: string;
  /** The user prompt */
  prompt: string;
  /** Optional system instruction */
  systemInstruction?: string;
  /** generationConfig overrides */
  generationConfig?: Partial<GeminiGenerationConfig>;
  /**
   * Ordered list of model names to try.
   * Defaults to GEMINI_FREE_MODELS (highest RPM first).
   */
  modelPriority?: string[];
  /**
   * Max retries per model on 429 before moving to the next model.
   * Default: 2 (so 3 total attempts per model).
   */
  maxRetriesPerModel?: number;
  /**
   * Initial back-off delay in ms. Doubles on each retry (exponential).
   * Default: 3 000 ms.
   */
  initialBackoffMs?: number;
  /**
   * Optional abort signal for cancellation.
   */
  signal?: AbortSignal;
}

export interface GeminiGenerationConfig {
  temperature: number;
  maxOutputTokens: number;
  topP: number;
  topK: number;
  /** 'application/json' | 'text/plain' | 'text/x.enum' */
  responseMimeType: string;
}

export interface GeminiResult {
  text: string;
  modelUsed: string;
  totalAttempts: number;
}

interface GeminiErrorBody {
  error?: { message?: string; code?: number; status?: string };
}

// ─── Core: single-model call ──────────────────────────────────────────────────

async function callGeminiOnce(
  apiKey: string,
  modelName: string,
  prompt: string,
  systemInstruction: string | undefined,
  generationConfig: Partial<GeminiGenerationConfig>,
  signal: AbortSignal | undefined,
): Promise<string> {
  const url = `${GEMINI_BASE}/${modelName}:generateContent?key=${apiKey}`;

  const body: Record<string, unknown> = {
    contents: [
      {
        role: 'user',
        parts: [{ text: prompt }],
      },
    ],
    generationConfig: {
      temperature: 0.8,
      maxOutputTokens: 4096,
      ...generationConfig,
    },
  };

  // systemInstruction is a top-level field, not part of contents
  if (systemInstruction) {
    body.systemInstruction = {
      role: 'user',
      parts: [{ text: systemInstruction }],
    };
  }

  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
    signal,
  });

  if (!response.ok) {
    const errJson: GeminiErrorBody = await response.json().catch(() => ({}));
    const message = errJson?.error?.message ?? `HTTP ${response.status}`;

    if (response.status === 429) {
      // Surface as a typed error so the retry loop can detect it
      const e = new Error(`429: ${message}`) as Error & { isRateLimit: true };
      (e as any).isRateLimit = true;
      throw e;
    }

    if (response.status === 400) {
      // 400 can mean: bad key, unsupported param, schema error — don't retry
      throw new Error(`400 Bad Request from Gemini (${modelName}): ${message}`);
    }

    if (response.status === 401 || response.status === 403) {
      throw new Error(`Auth error from Gemini — check your API key. (${message})`);
    }

    throw new Error(`Gemini error ${response.status} on ${modelName}: ${message}`);
  }

  const data = await response.json();

  // Extract text from the standard response shape
  const text: string | undefined =
    data?.candidates?.[0]?.content?.parts?.[0]?.text;

  if (!text) {
    // Could be a safety block
    const finishReason: string | undefined =
      data?.candidates?.[0]?.finishReason;
    throw new Error(
      `Empty response from Gemini (${modelName}). finishReason: ${finishReason ?? 'unknown'}`,
    );
  }

  return text;
}

// ─── Sleep helper ─────────────────────────────────────────────────────────────

const sleep = (ms: number): Promise<void> =>
  new Promise((resolve) => setTimeout(resolve, ms));

// ─── Q5: Complete fetch function — retry + model fallback ─────────────────────

/**
 * callGemini
 * ──────────────────────────────────────────────────────────────────────────
 * Calls the Gemini API with automatic 429-retry (exponential back-off) and
 * automatic fallback to the next model in the priority list.
 *
 * Free-tier strategy:
 *   • Start with gemini-2.5-flash-lite (15 RPM)
 *   • On 429: back off and retry up to maxRetriesPerModel times
 *   • If still 429 after retries: move to gemini-2.5-flash (10 RPM)
 *   • If still 429: move to gemini-2.0-flash (5 RPM, last resort)
 *   • If all models exhausted: throw with a user-friendly message
 *
 * Usage:
 *   const result = await callGemini({
 *     apiKey: 'AIza...',
 *     prompt: 'List 5 YouTube ideas for a tech channel',
 *     systemInstruction: 'You are a creative content strategist.',
 *     generationConfig: { responseMimeType: 'application/json' },
 *   });
 *   console.log(result.text);       // raw string (JSON or plain text)
 *   console.log(result.modelUsed);  // which model actually answered
 */
export async function callGemini(
  options: GeminiRequestOptions,
): Promise<GeminiResult> {
  const {
    apiKey,
    prompt,
    systemInstruction,
    generationConfig = {},
    modelPriority = GEMINI_FREE_MODELS.map((m) => m.name),
    maxRetriesPerModel = 2,
    initialBackoffMs = 3000,
    signal,
  } = options;

  if (!apiKey?.trim()) {
    throw new Error('Gemini API key is missing.');
  }

  let totalAttempts = 0;

  for (const modelName of modelPriority) {
    let backoffMs = initialBackoffMs;

    for (let attempt = 0; attempt <= maxRetriesPerModel; attempt++) {
      totalAttempts++;

      try {
        const text = await callGeminiOnce(
          apiKey,
          modelName,
          prompt,
          systemInstruction,
          generationConfig,
          signal,
        );

        return { text, modelUsed: modelName, totalAttempts };
      } catch (err: unknown) {
        const error = err as Error & { isRateLimit?: boolean };

        // AbortError → propagate immediately, no retry
        if (error.name === 'AbortError') throw error;

        const isRateLimit = error.isRateLimit === true ||
          error.message?.includes('429');

        if (isRateLimit && attempt < maxRetriesPerModel) {
          // Add ±20 % jitter to prevent thundering-herd on shared free-tier quota
          const jitter = backoffMs * 0.2 * (Math.random() - 0.5);
          const delay = Math.round(backoffMs + jitter);

          console.warn(
            `[gemini] 429 on ${modelName} (attempt ${attempt + 1}/${maxRetriesPerModel + 1}). ` +
            `Retrying in ${delay} ms…`,
          );

          await sleep(delay);
          backoffMs *= 2; // exponential back-off
          continue;
        }

        if (isRateLimit) {
          // Exhausted retries for this model — break inner loop, try next model
          console.warn(
            `[gemini] ${modelName} rate-limited after ${maxRetriesPerModel + 1} attempts. ` +
            `Falling back to next model…`,
          );
          break; // exit inner for-loop, continue outer model loop
        }

        // Non-429 error (400, 401, network, etc.) — throw immediately
        throw error;
      }
    }
  }

  // All models exhausted
  throw new Error(
    `Gemini rate limit exceeded across all models (${modelPriority.join(', ')}). ` +
    `Wait ~1 minute and try again, or enable billing in Google AI Studio ` +
    `to unlock Tier 1 limits (150–300 RPM).`,
  );
}

// ─── Convenience: call ListModels (capabilities only, not RPM quotas) ─────────

/**
 * listGeminiModels
 * Returns the raw model list from the API.
 * NOTE: This does NOT include RPM/RPD quota values — those live only in
 * your AI Studio project dashboard. Use this to verify which models your
 * key can access, not to discover rate limits.
 */
export async function listGeminiModels(apiKey: string): Promise<unknown[]> {
  const url = `${GEMINI_BASE.replace('/models', '')}models?key=${apiKey}&pageSize=50`;
  const res = await fetch(url);
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(`ListModels failed ${res.status}: ${(body as GeminiErrorBody)?.error?.message}`);
  }
  const data = await res.json();
  return (data.models ?? []) as unknown[];
}

// ─── Drop-in for your existing directGenerate.ts ─────────────────────────────
//
// Replace your current GEMINI_MODELS + callGeminiModel + callGemini block with:
//
//   import { callGemini, GeminiResult } from './geminiClient';
//
//   async function callGeminiProvider(system: string, user: string): Promise<string> {
//     const key = getStoredApiKey('gemini');
//     if (!key) throw new Error('No Gemini key');
//     const result: GeminiResult = await callGemini({
//       apiKey: key,
//       prompt: user,
//       systemInstruction: system,
//       generationConfig: { responseMimeType: 'application/json' },
//     });
//     return result.text;
//   }
