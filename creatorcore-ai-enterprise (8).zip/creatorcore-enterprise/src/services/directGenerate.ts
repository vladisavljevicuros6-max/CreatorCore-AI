/**
 * CreatorCore AI — Direct Browser Generation
 *
 * Calls AI APIs directly from the browser.
 * Supports Anthropic (Claude), Google (Gemini), and OpenAI (GPT-4o).
 * Auto-routes to best available model based on which keys are saved.
 *
 * Key priority fallback:
 *   1. Try the model the router selected
 *   2. Fall back to any other model whose key is available
 *   3. If no keys at all → prompt user to add one
 */

import { v4 as uuidv4 } from 'uuid';
import { GenerationRequest, GenerationBatch, Idea, AIModel } from '../types';
import { selectModel, buildIdeaSystemPrompt } from './ai/router';
import { callGemini } from './geminiClient';

// ─── Retry helper ─────────────────────────────────────────────────────────────
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

async function withRetry<T>(fn: () => Promise<T>, retries = 2, delayMs = 3000): Promise<T> {
  for (let i = 0; i <= retries; i++) {
    try {
      return await fn();
    } catch (err: any) {
      const is429 = err.message?.includes('429') || err.message?.includes('rate limit') || err.message?.includes('Rate limit');
      if (is429 && i < retries) {
        console.warn(`[retry] Rate limited, waiting ${delayMs}ms before retry ${i + 1}/${retries}...`);
        await sleep(delayMs);
        delayMs *= 2; // exponential backoff
        continue;
      }
      throw err;
    }
  }
  throw new Error('Max retries exceeded');
}


// ─── Dev Unlock Code ──────────────────────────────────────────────────────────
const DEV_UNLOCK_CODE = 'CC-ELITE-X9K2-2025';

export function validateDevCode(code: string): boolean {
  return code.trim() === DEV_UNLOCK_CODE;
}
export function isDevUnlocked(): boolean {
  return localStorage.getItem('cc_dev_unlocked') === 'true';
}
export function applyDevCode(code: string): boolean {
  if (validateDevCode(code)) {
    localStorage.setItem('cc_dev_unlocked', 'true');
    return true;
  }
  return false;
}
export function getEffectivePlan(): string {
  if (isDevUnlocked()) return 'pro';
  return localStorage.getItem('cc_plan') || 'free';
}

// ─── API Key storage ──────────────────────────────────────────────────────────
export function getStoredApiKey(provider: 'anthropic' | 'gemini' | 'openai' = 'anthropic'): string | null {
  return localStorage.getItem(`cc_key_${provider}`) || null;
}
export function setStoredApiKey(provider: 'anthropic' | 'gemini' | 'openai', key: string): void {
  localStorage.setItem(`cc_key_${provider}`, key.trim());
}
export function removeStoredApiKey(provider: 'anthropic' | 'gemini' | 'openai'): void {
  localStorage.removeItem(`cc_key_${provider}`);
}
export function hasAnyApiKey(): boolean {
  return !!(getStoredApiKey('anthropic') || getStoredApiKey('gemini') || getStoredApiKey('openai'));
}
export function getAvailableProviders(): ('anthropic' | 'gemini' | 'openai')[] {
  const providers: ('anthropic' | 'gemini' | 'openai')[] = [];
  if (getStoredApiKey('anthropic')) providers.push('anthropic');
  if (getStoredApiKey('gemini')) providers.push('gemini');
  if (getStoredApiKey('openai')) providers.push('openai');
  return providers;
}

// ─── JSON extraction helper ───────────────────────────────────────────────────
function extractJsonArray(text: string): Record<string, unknown>[] {
  const attempts = [
    () => JSON.parse(text),
    () => JSON.parse(text.replace(/```(?:json)?\s*/g, '').replace(/```\s*/g, '').trim()),
    () => {
      const s = text.indexOf('['), e = text.lastIndexOf(']');
      if (s !== -1 && e > s) return JSON.parse(text.slice(s, e + 1));
      throw new Error('no array');
    },
    () => {
      const s = text.indexOf('{'), e = text.lastIndexOf('}');
      if (s !== -1 && e > s) {
        const obj = JSON.parse(text.slice(s, e + 1));
        const arr = obj.ideas || obj.content || obj.data || obj.results;
        if (Array.isArray(arr)) return arr;
      }
      throw new Error('no object with array');
    },
  ];
  for (const attempt of attempts) {
    try {
      const result = attempt();
      if (Array.isArray(result)) return result as Record<string, unknown>[];
    } catch (_) {}
  }
  throw new Error('Could not parse AI response as JSON array. Try again.');
}

// ─── Map AIModel to provider ──────────────────────────────────────────────────
function modelToProvider(model: AIModel): 'anthropic' | 'gemini' | 'openai' {
  if (model === 'claude-sonnet' || model === 'claude-haiku') return 'anthropic';
  if (model === 'gemini-pro') return 'gemini';
  if (model === 'gpt-4o') return 'openai';
  return 'anthropic';
}

// ─── Build fallback order based on available keys ─────────────────────────────
function buildFallbackOrder(preferred: AIModel, available: ('anthropic' | 'gemini' | 'openai')[]): AIModel[] {
  const order: AIModel[] = [preferred];
  // Add alternatives if their provider key is available
  const providerToModel: Record<string, AIModel> = {
    anthropic: 'claude-sonnet',
    gemini: 'gemini-pro',
    openai: 'gpt-4o',
  };
  for (const p of available) {
    const m = providerToModel[p];
    if (m && !order.includes(m)) order.push(m);
  }
  // Always end with haiku as cheapest fallback if anthropic available
  if (available.includes('anthropic') && !order.includes('claude-haiku')) {
    order.push('claude-haiku');
  }
  return order;
}

// ─── Individual provider callers ──────────────────────────────────────────────

async function callAnthropic(model: AIModel, system: string, user: string): Promise<string> {
  const key = getStoredApiKey('anthropic');
  if (!key) throw new Error('No Anthropic key');
  const modelId = model === 'claude-haiku' ? 'claude-haiku-4-5-20251001' : 'claude-sonnet-4-20250514';
  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': key,
      'anthropic-version': '2023-06-01',
      'anthropic-dangerous-direct-browser-access': 'true',
    },
    body: JSON.stringify({ model: modelId, max_tokens: 4096, system, messages: [{ role: 'user', content: user }] }),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    const msg = (err as any)?.error?.message || `Anthropic error ${res.status}`;
    if (res.status === 401) throw new Error('Invalid Anthropic API key.');
    if (res.status === 429) throw new Error('Anthropic rate limit hit. Wait a moment.');
    throw new Error(msg);
  }
  const data = await res.json();
  return data.content?.[0]?.text ?? '';
}

// ─── Gemini — uses geminiClient.ts (proper retry + model fallback) ────────────
async function callGeminiProvider(system: string, user: string): Promise<string> {
  const key = getStoredApiKey('gemini');
  if (!key) throw new Error('No Gemini key');
  const result = await callGemini({
    apiKey: key,
    prompt: user,
    systemInstruction: system,
    generationConfig: { responseMimeType: 'application/json', temperature: 0.8, maxOutputTokens: 4096 },
  });
  return result.text;
}

async function callOpenAI(system: string, user: string): Promise<string> {
  const key = getStoredApiKey('openai');
  if (!key) throw new Error('No OpenAI key');
  const res = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${key}` },
    body: JSON.stringify({
      model: 'gpt-4o',
      response_format: { type: 'json_object' },
      max_tokens: 4096,
      messages: [
        { role: 'system', content: system + '\n\nReturn a JSON object with key "ideas" containing an array.' },
        { role: 'user', content: user },
      ],
    }),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    const msg = (err as any)?.error?.message || `OpenAI error ${res.status}`;
    if (res.status === 401) throw new Error('Invalid OpenAI API key.');
    if (res.status === 429) throw new Error('OpenAI rate limit hit. Wait a moment.');
    throw new Error(msg);
  }
  const data = await res.json();
  return data.choices?.[0]?.message?.content ?? '';
}

async function callModel(model: AIModel, system: string, user: string): Promise<string> {
  const provider = modelToProvider(model);
  if (provider === 'anthropic') return callAnthropic(model, system, user);
  if (provider === 'gemini') return callGeminiProvider(system, user);
  if (provider === 'openai') return callOpenAI(system, user);
  throw new Error(`Unknown provider for model ${model}`);
}

// ─── Idea hydration ───────────────────────────────────────────────────────────
function hydrateIdea(raw: Record<string, unknown>, req: GenerationRequest, model: AIModel, ms: number): Idea {
  return {
    id: uuidv4(),
    workspaceId: req.workspaceId || 'personal',
    createdBy: 'local',
    platform: req.platform,
    title: String(raw.title || ''),
    hook: String(raw.hook || ''),
    explanation: String(raw.explanation || ''),
    productionTips: String(raw.productionTips || ''),
    thumbnailSuggestion: String(raw.thumbnailSuggestion || ''),
    seoTitle: String(raw.seoTitle || ''),
    seoDescription: String(raw.seoDescription || ''),
    hashtags: Array.isArray(raw.hashtags) ? raw.hashtags.map(String) : [],
    viralityScore: Math.min(100, Math.max(1, Number(raw.viralityScore) || 70)),
    estimatedReach: Number(raw.estimatedReach) || undefined,
    status: 'draft',
    aiModel: model,
    generationMs: ms,
    tags: [],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
}

// ─── Main: Generate Ideas ─────────────────────────────────────────────────────
export async function generateIdeasDirect(req: GenerationRequest): Promise<GenerationBatch> {
  if (!hasAnyApiKey()) {
    throw new Error('No API key found. Add at least one key in Account settings (Anthropic, Gemini, or OpenAI).');
  }

  const plan = getEffectivePlan();
  const routing = selectModel(req, plan);
  const available = getAvailableProviders();
  const count = Math.min(req.count || 3, plan !== 'free' ? 10 : 3);
  const startMs = Date.now();

  const systemPrompt = buildIdeaSystemPrompt(req);
  const userPrompt = `Generate exactly ${count} unique content ideas. Return ONLY a valid JSON array — no markdown, no explanation. Start with [ and end with ].

Each object:
{
  "title": string,
  "hook": string,
  "explanation": string,
  "productionTips": string,
  "thumbnailSuggestion": string,
  "seoTitle": string,
  "seoDescription": string,
  "hashtags": string[] (5 items),
  "viralityScore": number (1-100),
  "estimatedReach": number
}`;

  // Build fallback order — only include models whose provider key is available
  const allFallbacks = buildFallbackOrder(routing.model, available);
  const validFallbacks = allFallbacks.filter((m) => available.includes(modelToProvider(m)));

  if (validFallbacks.length === 0) {
    throw new Error(`No API key available for the selected model (${routing.model}). Add a key in Account settings.`);
  }

  let lastError = '';
  let usedModel: AIModel = validFallbacks[0];

  for (const model of validFallbacks) {
    try {
      const text = await callModel(model, systemPrompt, userPrompt);
      const rawIdeas = extractJsonArray(text);
      usedModel = model;

      const ideas: Idea[] = rawIdeas.slice(0, count).map((raw) =>
        hydrateIdea(raw, req, model, Date.now() - startMs)
      );

      return {
        id: uuidv4(),
        workspaceId: req.workspaceId || 'personal',
        createdBy: 'local',
        createdAt: new Date().toISOString(),
        request: req,
        ideas,
        modelUsed: model,
        totalMs: Date.now() - startMs,
      };
    } catch (err: any) {
      lastError = err.message;
      console.warn(`[generate] ${model} failed: ${err.message} — trying next fallback`);
    }
  }

  throw new Error(`All models failed. Last error: ${lastError}`);
}

// ─── Script Generation ────────────────────────────────────────────────────────
export async function generateScriptDirect(idea: Idea): Promise<string> {
  if (!hasAnyApiKey()) {
    throw new Error('No API key found. Add a key in Account settings.');
  }

  const plan = getEffectivePlan();
  const available = getAvailableProviders();

  const platformInstructions: Record<string, string> = {
    'YouTube': 'Write an 8-12 minute script. Include [HOOK] section, timestamps, [B-ROLL] cues, [CAMERA] directions, word-for-word dialogue, strong CTA at end.',
    'YouTube Shorts': 'Write a 45-60 second script. No intro — instant hook, single punchy point, end loop.',
    'TikTok': 'Write a 30-60 second script. Instant hook (no intro), [OVERLAY: text] cues, music/sound notes, fast-cut pacing.',
    'Instagram Reels': 'Write a 30-45 second script. Visual-first, hook in first frame, save-worthy insight.',
    'LinkedIn': 'Write a LinkedIn post/video script. Strong first line, personal story, key lesson, understated CTA.',
    'Twitter/X': 'Write an 8-12 tweet thread. Hook tweet, numbered insights, engagement tweet at end.',
    'Podcast': 'Write a 15-20 minute podcast segment with intro, talking points, natural banter prompts, outro.',
    'Twitch': 'Write a stream segment script with community interactions, hype moments, engagement prompts.',
  };

  const system = `You are a world-class ${idea.platform} scriptwriter.
${platformInstructions[idea.platform] || platformInstructions['YouTube']}
Write ONLY the script — no meta-commentary. Start directly with the content.`;

  const user = `Title: ${idea.title}
Hook: ${idea.hook}
Concept: ${idea.explanation}
Production notes: ${idea.productionTips}
${idea.curatorNotes ? `Creator direction: ${idea.curatorNotes}` : ''}

Write the complete production-ready script now.`;

  // For scripts: prefer Claude Sonnet (best narrative), fall back to others
  const scriptOrder: AIModel[] = plan !== 'free'
    ? ['claude-sonnet', 'gemini-pro', 'gpt-4o', 'claude-haiku']
    : ['claude-haiku', 'gemini-pro', 'gpt-4o'];

  const validOrder = scriptOrder.filter((m) => available.includes(modelToProvider(m)));

  if (validOrder.length === 0) throw new Error('No API key available for script generation.');

  for (const model of validOrder) {
    try {
      // For scripts we need longer output — use higher token limit
      const provider = modelToProvider(model);
      if (provider === 'anthropic') {
        const key = getStoredApiKey('anthropic')!;
        const modelId = model === 'claude-haiku' ? 'claude-haiku-4-5-20251001' : 'claude-sonnet-4-20250514';
        const res = await fetch('https://api.anthropic.com/v1/messages', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'x-api-key': key, 'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true' },
          body: JSON.stringify({ model: modelId, max_tokens: 8192, system, messages: [{ role: 'user', content: user }] }),
        });
        if (!res.ok) throw new Error(`Anthropic ${res.status}`);
        const data = await res.json();
        return data.content?.[0]?.text ?? '';
      } else if (provider === 'gemini') {
        const key = getStoredApiKey('gemini')!;
        return await callGeminiProvider(system, user);
      } else {
        const key = getStoredApiKey('openai')!;
        const res = await fetch('https://api.openai.com/v1/chat/completions', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${key}` },
          body: JSON.stringify({ model: 'gpt-4o', max_tokens: 8192, messages: [{ role: 'system', content: system }, { role: 'user', content: user }] }),
        });
        if (!res.ok) throw new Error(`OpenAI ${res.status}`);
        const data = await res.json();
        return data.choices?.[0]?.message?.content ?? '';
      }
    } catch (err: any) {
      console.warn(`[script] ${model} failed: ${err.message}`);
    }
  }

  throw new Error('Script generation failed across all available models.');
}
