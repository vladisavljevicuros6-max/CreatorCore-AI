import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router';
import { AnimatePresence, motion } from 'motion/react';
import { Loader2, Sparkles, Eye, EyeOff, UserPlus, LogIn } from 'lucide-react';
import { Sidebar } from './components/Sidebar';
import { GDPRBanner } from './components/GDPRBanner';
import { OnboardingTour } from './components/OnboardingTour';
import { GeneratePage } from './pages/GeneratePage';
import { CalendarPage } from './pages/CalendarPage';
import { ProfilePage } from './pages/ProfilePage';
import { WorkspacePage } from './pages/WorkspacePage';
import { LandingPage } from './pages/LandingPage';

export interface AuthUser {
  id: string;
  name: string;
  email: string;
  plan: string;
  onboardingCompleted: boolean;
}

// ─── Simple local account storage ─────────────────────────────────────────────
type AccountStore = Record<string, { password: string; user: AuthUser }>;

function getStoredAccounts(): AccountStore {
  try { return JSON.parse(localStorage.getItem('cc_accounts') || '{}'); }
  catch { return {}; }
}

function saveAccount(email: string, password: string, user: AuthUser) {
  const accounts = getStoredAccounts();
  accounts[email.toLowerCase()] = { password, user };
  localStorage.setItem('cc_accounts', JSON.stringify(accounts));
}

export function updateStoredUser(user: AuthUser) {
  const accounts = getStoredAccounts();
  const key = user.email.toLowerCase();
  if (accounts[key]) { accounts[key].user = user; localStorage.setItem('cc_accounts', JSON.stringify(accounts)); }
  localStorage.setItem('cc_session', JSON.stringify(user));
}

// ─── Auth Screen ──────────────────────────────────────────────────────────────
function AuthScreen({ onAuth }: { onAuth: (user: AuthUser) => void }) {
  const [mode, setMode] = useState<'landing' | 'signin' | 'signup'>('landing');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    await new Promise((r) => setTimeout(r, 350));

    if (mode === 'signup') {
      if (!name.trim()) { setError('Name is required.'); setLoading(false); return; }
      if (password.length < 6) { setError('Password must be at least 6 characters.'); setLoading(false); return; }
      const existing = getStoredAccounts();
      if (existing[email.toLowerCase()]) { setError('Account already exists. Sign in instead.'); setLoading(false); return; }
      const user: AuthUser = { id: `user_${Date.now()}`, name: name.trim(), email: email.toLowerCase().trim(), plan: 'free', onboardingCompleted: false };
      saveAccount(email, password, user);
      setLoading(false);
      onAuth(user);
    } else {
      const accounts = getStoredAccounts();
      const record = accounts[email.toLowerCase().trim()];
      if (!record || record.password !== password) { setError('Incorrect email or password.'); setLoading(false); return; }
      setLoading(false);
      onAuth(record.user);
    }
  };

  if (mode === 'landing') {
    return <LandingPage onSignIn={() => setMode('signin')} onSignUp={() => setMode('signup')} />;
  }

  return (
    <div className="h-screen bg-black flex items-center justify-center p-6">
      <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-md space-y-7">
        <div className="text-center space-y-3">
          <div className="w-14 h-14 bg-indigo-500 rounded-2xl flex items-center justify-center mx-auto shadow-2xl shadow-indigo-500/30">
            <Sparkles className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-white">{mode === 'signup' ? 'Create your account' : 'Welcome back'}</h1>
          <p className="text-zinc-400 text-sm">{mode === 'signup' ? 'Free forever. No credit card needed.' : 'Sign in to CreatorCore AI'}</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {mode === 'signup' && (
            <div className="space-y-1.5">
              <label className="text-sm font-medium text-zinc-300">Your Name</label>
              <input type="text" required value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g., Uros V."
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 text-white focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all" />
            </div>
          )}
          <div className="space-y-1.5">
            <label className="text-sm font-medium text-zinc-300">Email Address</label>
            <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com"
              className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 text-white focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all" />
          </div>
          <div className="space-y-1.5">
            <label className="text-sm font-medium text-zinc-300">Password</label>
            <div className="relative">
              <input type={showPass ? 'text' : 'password'} required value={password} onChange={(e) => setPassword(e.target.value)}
                placeholder={mode === 'signup' ? 'At least 6 characters' : '••••••••'}
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 pr-11 text-white focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all" />
              <button type="button" onClick={() => setShowPass(!showPass)} className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-zinc-300">
                {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>
          {error && <p className="text-red-400 text-sm bg-red-400/10 border border-red-400/20 rounded-lg px-3 py-2">{error}</p>}
          <button type="submit" disabled={loading}
            className="w-full bg-indigo-500 hover:bg-indigo-600 disabled:bg-indigo-500/50 text-white font-bold py-3 rounded-xl transition-all flex items-center justify-center gap-2 shadow-lg">
            {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : mode === 'signup'
              ? <><UserPlus className="w-4 h-4" /> Create Account</>
              : <><LogIn className="w-4 h-4" /> Sign In</>}
          </button>
        </form>

        <div className="text-center text-sm text-zinc-500">
          {mode === 'signup'
            ? <>Already have an account? <button onClick={() => { setMode('signin'); setError(''); }} className="text-indigo-400 hover:text-indigo-300 font-medium">Sign in</button></>
            : <>No account yet? <button onClick={() => { setMode('signup'); setError(''); }} className="text-indigo-400 hover:text-indigo-300 font-medium">Create one free</button></>}
        </div>
        <button onClick={() => setMode('landing')} className="w-full text-center text-xs text-zinc-700 hover:text-zinc-500 transition-colors">← Back to home</button>
      </motion.div>
    </div>
  );
}

// ─── Main App ─────────────────────────────────────────────────────────────────
export default function App() {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [showOnboarding, setShowOnboarding] = useState(false);

  useEffect(() => {
    const session = localStorage.getItem('cc_session');
    if (session) {
      try {
        const parsed = JSON.parse(session) as AuthUser;
        setUser(parsed);
        if (!parsed.onboardingCompleted) setShowOnboarding(true);
      } catch (_) {}
    }
    setLoading(false);
  }, []);

  const handleAuth = (newUser: AuthUser) => {
    localStorage.setItem('cc_session', JSON.stringify(newUser));
    setUser(newUser);
    if (!newUser.onboardingCompleted) setShowOnboarding(true);
  };

  const completeOnboarding = () => {
    if (!user) return;
    const updated = { ...user, onboardingCompleted: true };
    updateStoredUser(updated);
    setUser(updated);
    setShowOnboarding(false);
  };

  const handleUserUpdate = (updated: AuthUser) => {
    updateStoredUser(updated);
    setUser(updated);
  };

  if (loading) {
    return <div className="h-screen bg-black flex items-center justify-center"><Loader2 className="w-8 h-8 animate-spin text-indigo-500" /></div>;
  }

  if (!user) return <AuthScreen onAuth={handleAuth} />;

  return (
    <BrowserRouter>
      <div className="flex h-screen bg-black text-white font-sans selection:bg-indigo-500/30">
        <Sidebar user={user} />
        <main className="flex-1 flex flex-col min-w-0 overflow-hidden relative">
          <Routes>
            <Route path="/" element={<GeneratePage />} />
            <Route path="/calendar" element={<CalendarPage />} />
            <Route path="/workspace" element={<WorkspacePage />} />
            <Route path="/profile" element={<ProfilePage user={user} onUserUpdate={handleUserUpdate} />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
          <GDPRBanner />
        </main>
        <AnimatePresence>
          {showOnboarding && <OnboardingTour onComplete={completeOnboarding} />}
        </AnimatePresence>
      </div>
    </BrowserRouter>
  );
}
