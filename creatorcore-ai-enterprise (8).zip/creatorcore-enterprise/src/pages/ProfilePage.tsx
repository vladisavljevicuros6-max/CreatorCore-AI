import React, { useState } from 'react';
import {
  Key, Unlock, CheckCircle, XCircle, Eye, EyeOff,
  Sparkles, Copy, Check, LogOut, Shield, Zap, Crown, ExternalLink, Trash2
} from 'lucide-react';
import { cn } from '../lib/utils';
import {
  applyDevCode, isDevUnlocked,
  getStoredApiKey, setStoredApiKey, removeStoredApiKey,
  getAvailableProviders
} from '../services/directGenerate';
import type { AuthUser } from '../App';

interface ProfilePageProps {
  user: AuthUser;
  onUserUpdate: (user: AuthUser) => void;
}

type Provider = 'anthropic' | 'gemini' | 'openai';

interface ProviderConfig {
  id: Provider;
  name: string;
  models: string;
  keyPrefix: string;
  keyPlaceholder: string;
  docsUrl: string;
  color: string;
  free: string;
  logo: string;
}

const PROVIDERS: ProviderConfig[] = [
  {
    id: 'anthropic',
    name: 'Anthropic',
    models: 'Claude Sonnet 4 · Claude Haiku 4.5',
    keyPrefix: 'sk-ant-',
    keyPlaceholder: 'sk-ant-api03-...',
    docsUrl: 'https://console.anthropic.com/account/keys',
    color: 'text-orange-400 border-orange-500/20 bg-orange-500/5',
    free: '$5 free credit on signup',
    logo: '🟠',
  },
  {
    id: 'gemini',
    name: 'Google Gemini',
    models: 'Gemini 1.5 Pro',
    keyPrefix: 'AIza',
    keyPlaceholder: 'AIzaSy...',
    docsUrl: 'https://aistudio.google.com/app/apikey',
    color: 'text-blue-400 border-blue-500/20 bg-blue-500/5',
    free: 'Free tier available (15 req/min)',
    logo: '🔵',
  },
  {
    id: 'openai',
    name: 'OpenAI',
    models: 'GPT-4o',
    keyPrefix: 'sk-',
    keyPlaceholder: 'sk-proj-...',
    docsUrl: 'https://platform.openai.com/api-keys',
    color: 'text-emerald-400 border-emerald-500/20 bg-emerald-500/5',
    free: '$5 free credit on signup',
    logo: '🟢',
  },
];

// Auto-detect provider from key prefix
function detectProvider(key: string): Provider | null {
  const k = key.trim();
  if (k.startsWith('sk-ant-')) return 'anthropic';
  if (k.startsWith('AIza')) return 'gemini';
  if (k.startsWith('sk-') && !k.startsWith('sk-ant-')) return 'openai';
  return null;
}


function ApiKeyRow({ provider, onSaved }: { provider: ProviderConfig; onSaved: () => void }) {
  const [value, setValue] = useState(getStoredApiKey(provider.id) || '');
  const [show, setShow] = useState(false);
  const [saved, setSaved] = useState(false);
  const [copied, setCopied] = useState(false);
  const hasKey = !!getStoredApiKey(provider.id);

  const handleSave = () => {
    if (!value.trim()) return;
    setStoredApiKey(provider.id, value.trim());
    setSaved(true);
    onSaved();
    setTimeout(() => setSaved(false), 2500);
  };

  const handleRemove = () => {
    removeStoredApiKey(provider.id);
    setValue('');
    onSaved();
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(value).then(() => { setCopied(true); setTimeout(() => setCopied(false), 2000); });
  };

  return (
    <div className={cn('rounded-xl border p-4 space-y-3', provider.color)}>
      {/* Honeypot fields — Chrome autofills these instead of the real API key input */}
      <div style={{ position: 'absolute', left: '-9999px', top: '-9999px', opacity: 0, pointerEvents: 'none' }} aria-hidden="true">
        <input type="text" name="username" autoComplete="username" tabIndex={-1} />
        <input type="password" name="password" autoComplete="current-password" tabIndex={-1} />
      </div>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <span className="text-lg">{provider.logo}</span>
          <div>
            <div className="text-sm font-semibold text-white flex items-center gap-2">
              {provider.name}
              {hasKey && <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 inline-block" title="Key saved" />}
            </div>
            <div className="text-[11px] text-zinc-500">{provider.models}</div>
          </div>
        </div>
        <a href={provider.docsUrl} target="_blank" rel="noopener noreferrer"
          className="flex items-center gap-1 text-xs text-zinc-500 hover:text-zinc-300 transition-colors">
          Get key <ExternalLink className="w-3 h-3" />
        </a>
      </div>

      <div className="flex gap-2">
        <div className="relative flex-1">
          <input
            type="text"
            value={show ? value : value ? '•'.repeat(Math.min(value.length, 32)) : ''}
            onChange={(e) => {
              // Only update on real typing, not autofill replacement
              const v = e.target.value;
              if (!v.includes('•')) setValue(v);
            }}
            onFocus={(e) => { e.target.setAttribute('type', 'text'); }}
            onKeyDown={(e) => e.key === 'Enter' && handleSave()}
            placeholder={provider.keyPlaceholder}
            autoComplete="new-password"
            name={`api-key-${provider.id}-${Math.random().toString(36).slice(2)}`}
            data-form-type="other"
            data-lpignore="true"
            spellCheck={false}
            className="w-full bg-black border border-zinc-800 rounded-lg px-3 py-2.5 pr-16 text-zinc-200 font-mono text-xs
              focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none"
          />
          <div className="absolute right-1 top-1/2 -translate-y-1/2 flex gap-0.5">
            <button onClick={() => setShow(!show)} className="p-1.5 text-zinc-600 hover:text-zinc-300">
              {show ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
            </button>
            {value && <button onClick={handleCopy} className="p-1.5 text-zinc-600 hover:text-zinc-300">
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            </button>}
          </div>
        </div>
        <button onClick={handleSave} disabled={!value.trim()}
          className="px-3 py-2.5 bg-zinc-800 hover:bg-zinc-700 disabled:opacity-40 text-zinc-200 text-xs rounded-lg font-medium transition-colors flex items-center gap-1.5 whitespace-nowrap border border-zinc-700">
          {saved ? <><Check className="w-3.5 h-3.5 text-emerald-400" /> Saved</> : 'Save'}
        </button>
        {hasKey && <button onClick={handleRemove} className="p-2.5 bg-zinc-800 hover:bg-red-900/40 text-zinc-500 hover:text-red-400 rounded-lg border border-zinc-700 transition-colors" title="Remove key">
          <Trash2 className="w-3.5 h-3.5" />
        </button>}
      </div>

      <div className="text-[11px] text-zinc-600 flex items-center gap-1">
        🆓 {provider.free}
      </div>
    </div>
  );
}


// Smart paste box — auto-detects provider from key format
function SmartPasteBox({ onDetected }: { onDetected: () => void }) {
  const [value, setValue] = useState('');
  const [detected, setDetected] = useState<Provider | null>(null);
  const [status, setStatus] = useState<'idle' | 'saved' | 'unknown'>('idle');

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setValue(val);
    const provider = detectProvider(val);
    setDetected(provider);
    setStatus('idle');
  };

  const handleSave = () => {
    if (!detected || !value.trim()) return;
    setStoredApiKey(detected, value.trim());
    setStatus('saved');
    setValue('');
    setDetected(null);
    onDetected();
    setTimeout(() => setStatus('idle'), 2500);
  };

  const providerLabel: Record<Provider, string> = {
    anthropic: '🟠 Anthropic (Claude)',
    gemini: '🔵 Google Gemini',
    openai: '🟢 OpenAI (GPT-4o)',
  };

  return (
    <div className="bg-zinc-800/40 border border-zinc-700 rounded-xl p-4 space-y-2">
      <div className="text-xs font-medium text-zinc-400 flex items-center gap-1.5">
        <Zap className="w-3.5 h-3.5 text-amber-400" />
        Quick paste — auto-detects provider
      </div>
      <div className="flex gap-2">
        <div className="relative flex-1">
          <input
            type="text"
            value={value}
            onChange={handleChange}
            placeholder="Paste any API key here..."
            autoComplete="new-password"
            name="smart-paste-api-key"
            data-form-type="other"
            data-lpignore="true"
            spellCheck={false}
            className={cn(
              'w-full bg-black border rounded-lg px-3 py-2.5 text-zinc-200 font-mono text-xs focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all',
              detected ? 'border-emerald-500/40' : 'border-zinc-800'
            )}
          />
          {detected && (
            <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[10px] text-emerald-400 font-medium">
              {providerLabel[detected]}
            </span>
          )}
        </div>
        <button
          onClick={handleSave}
          disabled={!detected}
          className="px-3 py-2.5 bg-indigo-500 hover:bg-indigo-600 disabled:bg-zinc-800 disabled:text-zinc-600 text-white text-xs rounded-lg font-medium transition-colors whitespace-nowrap"
        >
          {status === 'saved' ? '✓ Saved!' : 'Save'}
        </button>
      </div>
      {value && !detected && (
        <p className="text-[11px] text-zinc-500">Key format not recognized — fill in manually below.</p>
      )}
    </div>
  );
}

export function ProfilePage({ user, onUserUpdate }: ProfilePageProps) {
  const [devCode, setDevCode] = useState('');
  const [devStatus, setDevStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [devUnlocked, setDevUnlocked] = useState(isDevUnlocked());
  const [availableCount, setAvailableCount] = useState(getAvailableProviders().length);

  const effectivePlan = devUnlocked ? 'pro' : user.plan;

  const handleApplyDevCode = () => {
    const result = applyDevCode(devCode);
    if (result) {
      setDevStatus('success');
      setDevUnlocked(true);
      onUserUpdate({ ...user, plan: 'pro' });
    } else {
      setDevStatus('error');
      setTimeout(() => setDevStatus('idle'), 2500);
    }
  };

  const handleSignOut = () => {
    localStorage.removeItem('cc_session');
    window.location.reload();
  };

  const refreshKeyCount = () => setAvailableCount(getAvailableProviders().length);

  const features = effectivePlan === 'pro'
    ? ['Up to 10 ideas per generation', 'Claude Sonnet + all models', 'Full script generation', 'Team workspace', 'Approval workflow', 'API access']
    : ['3 ideas per generation', 'Claude Haiku / free-tier models', 'Content calendar', '1 workspace'];

  return (
    <div className="flex-1 p-4 md:p-8 overflow-y-auto pb-24 md:pb-8">
      <div className="max-w-2xl mx-auto space-y-6">

        <header>
          <h1 className="text-2xl md:text-3xl font-bold text-white tracking-tight">Account Settings</h1>
          <p className="text-zinc-400 mt-1 text-sm">API keys, unlock codes, and account management.</p>
        </header>

        {/* Plan Badge */}
        <div className={cn('rounded-2xl border p-5', effectivePlan === 'pro' ? 'bg-indigo-500/5 border-indigo-500/30' : 'bg-zinc-900 border-zinc-800')}>
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              {effectivePlan === 'pro' ? <Crown className="w-5 h-5 text-amber-400" /> : <Shield className="w-5 h-5 text-zinc-400" />}
              <h2 className="text-base font-semibold text-white">
                {effectivePlan === 'pro' ? 'Pro Plan' : 'Free Plan'}
                {devUnlocked && <span className="ml-2 text-xs text-amber-400 font-normal">(Dev Unlocked)</span>}
              </h2>
            </div>
            <span className={cn('text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider', effectivePlan === 'pro' ? 'bg-indigo-500/20 text-indigo-300' : 'bg-zinc-700 text-zinc-400')}>
              {effectivePlan}
            </span>
          </div>
          <div className="grid grid-cols-2 gap-1.5">
            {features.map((f) => (
              <div key={f} className="flex items-center gap-1.5 text-xs text-zinc-300">
                <CheckCircle className="w-3 h-3 text-emerald-400 flex-shrink-0" />{f}
              </div>
            ))}
          </div>
        </div>

        {/* Profile */}
        <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-5">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-indigo-600 flex items-center justify-center text-lg font-bold text-white flex-shrink-0">
              {user.name[0].toUpperCase()}
            </div>
            <div>
              <div className="text-white font-semibold">{user.name}</div>
              <div className="text-zinc-400 text-sm">{user.email}</div>
            </div>
          </div>
        </div>

        {/* API Keys — all three providers */}
        <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Key className="w-5 h-5 text-indigo-400" />
              <h2 className="text-base font-semibold text-white">AI Provider Keys</h2>
            </div>
            <span className={cn('text-xs px-2 py-0.5 rounded-full', availableCount > 0 ? 'bg-emerald-500/10 text-emerald-400' : 'bg-zinc-800 text-zinc-500')}>
              {availableCount} / 3 connected
            </span>
          </div>

          <p className="text-sm text-zinc-400">
            Add at least one key to start. Paste any key below and it auto-fills the right provider — or fill them in manually.
          </p>

          {/* Smart paste detector */}
          <SmartPasteBox onDetected={refreshKeyCount} />

          <div className="space-y-3">
            {PROVIDERS.map((p) => (
              <ApiKeyRow key={p.id} provider={p} onSaved={refreshKeyCount} />
            ))}
          </div>

          <div className="bg-zinc-800/40 rounded-xl p-3 text-xs text-zinc-500">
            🔒 All keys are stored locally in your browser only — they are never sent to our servers. Each API call goes directly from your browser to the provider.
          </div>
        </div>

        {/* Routing info */}
        <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-5 space-y-3">
          <h2 className="text-sm font-semibold text-white">How model routing works</h2>
          <div className="space-y-2 text-xs text-zinc-400">
            {[
              { platform: 'TikTok / Shorts / Reels', model: 'Gemini 1.5 Pro', reason: 'Best for punchy short-form hooks' },
              { platform: 'LinkedIn / Thought Leadership', model: 'Claude Sonnet', reason: 'Best narrative depth (Pro+)' },
              { platform: 'Educational YouTube', model: 'Claude Sonnet → GPT-4o', reason: 'Structured long-form content' },
              { platform: 'Everything else', model: 'Gemini Pro → Claude', reason: 'Best cost/quality ratio' },
              { platform: 'Free tier', model: 'Claude Haiku', reason: 'Fast and cheapest' },
            ].map((row) => (
              <div key={row.platform} className="flex gap-3">
                <span className="text-zinc-600 w-44 flex-shrink-0">{row.platform}</span>
                <span className="text-indigo-300 w-36 flex-shrink-0">{row.model}</span>
                <span className="text-zinc-500">{row.reason}</span>
              </div>
            ))}
          </div>
          <p className="text-xs text-zinc-600">If the preferred model's key isn't saved, it automatically falls back to whichever key you do have.</p>
        </div>

        {/* Dev Unlock Code */}
        <div className={cn('rounded-2xl border p-5 space-y-4', devUnlocked ? 'bg-amber-500/5 border-amber-500/20' : 'bg-zinc-900 border-zinc-800')}>
          <div className="flex items-center gap-2">
            <Unlock className="w-5 h-5 text-amber-400" />
            <h2 className="text-base font-semibold text-white">Unlock Code</h2>
          </div>
          {devUnlocked ? (
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-amber-500/20 flex items-center justify-center"><Sparkles className="w-5 h-5 text-amber-400" /></div>
              <div>
                <div className="text-emerald-400 font-semibold text-sm">✓ Pro features active on this account</div>
                <div className="text-zinc-500 text-xs mt-0.5">Claude Sonnet, 10 ideas/gen, team workspaces — all unlocked.</div>
              </div>
            </div>
          ) : (
            <>
              <p className="text-sm text-zinc-400">Enter your unlock code to activate Pro features on this account.</p>
              <div className="flex gap-2">
                <input type="text" value={devCode} onChange={(e) => setDevCode(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleApplyDevCode()}
                  placeholder="CC-XXXX-XXXX-XXXX"
                  className={cn('flex-1 bg-black border rounded-xl px-4 py-3 text-zinc-200 font-mono text-sm focus:ring-2 focus:ring-amber-500 focus:border-transparent outline-none', devStatus === 'error' ? 'border-red-500/50' : 'border-zinc-800')} />
                <button onClick={handleApplyDevCode} disabled={!devCode.trim()}
                  className="px-4 py-3 bg-amber-500 hover:bg-amber-400 disabled:bg-zinc-800 disabled:text-zinc-600 text-black text-sm rounded-xl font-bold transition-colors flex items-center gap-2">
                  <Zap className="w-4 h-4" /> Apply
                </button>
              </div>
              {devStatus === 'error' && <div className="flex items-center gap-2 text-xs text-red-400"><XCircle className="w-3.5 h-3.5" /> Invalid code.</div>}
            </>
          )}
        </div>

        {/* Sign Out */}
        <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-5">
          <p className="text-zinc-500 text-sm mb-3">Signed in as <span className="text-zinc-300">{user.email}</span></p>
          <button onClick={handleSignOut}
            className="flex items-center gap-2 px-4 py-2.5 bg-zinc-800 hover:bg-red-900/30 hover:border-red-500/30 text-zinc-300 hover:text-red-300 text-sm rounded-xl border border-zinc-700 transition-all">
            <LogOut className="w-4 h-4" /> Sign out
          </button>
        </div>

      </div>
    </div>
  );
}
