import React from 'react';
import { motion } from 'motion/react';
import { Sparkles, Zap, Users, Shield, BarChart3, Globe, Check, ArrowRight } from 'lucide-react';

interface LandingPageProps {
  onSignIn: () => void;
  onSignUp: () => void;
}

const FEATURES = [
  { icon: <Sparkles className="w-5 h-5 text-indigo-400" />, title: 'Multi-Model AI', desc: 'Auto-routes to Claude Sonnet, Gemini Pro, or GPT-4o depending on your platform and style.' },
  { icon: <Zap className="w-5 h-5 text-amber-400" />, title: 'Full Scripts in 3s', desc: 'One-click production scripts with B-roll cues, timestamps, and platform-native pacing.' },
  { icon: <Users className="w-5 h-5 text-emerald-400" />, title: 'Team Collaboration', desc: 'Invite editors and clients. Human-in-loop approval workflow keeps quality high.' },
  { icon: <BarChart3 className="w-5 h-5 text-blue-400" />, title: 'Content Calendar', desc: 'Schedule approved ideas. Visual calendar with drag-and-drop publishing pipeline.' },
  { icon: <Globe className="w-5 h-5 text-purple-400" />, title: 'White-Label', desc: 'Deploy under your own domain and brand. Perfect for content agencies.' },
  { icon: <Shield className="w-5 h-5 text-rose-400" />, title: 'API Access', desc: 'Integrate idea generation into your own tools with our REST API and SDKs.' },
];

const PLANS = [
  { name: 'Free', price: '$0', features: ['3 ideas/generation', 'Claude Haiku model', 'Basic calendar', '1 workspace'], cta: 'Start free', highlight: false },
  { name: 'Pro', price: '$29', period: '/mo', features: ['10 ideas/generation', 'Claude Sonnet + Gemini Pro', 'Full scripts', 'Content calendar', 'Priority support'], cta: 'Start Pro', highlight: true },
  { name: 'Team', price: '$79', period: '/mo', features: ['Unlimited ideas', 'All models', 'Team workspace (5 seats)', 'Approval workflow', 'API access'], cta: 'Start Team', highlight: false },
  { name: 'Enterprise', price: 'Custom', features: ['Unlimited everything', 'White-label domain', 'SSO', 'SLA', 'Dedicated support'], cta: 'Contact us', highlight: false },
];

export function LandingPage({ onSignIn, onSignUp }: LandingPageProps) {
  return (
    <div className="min-h-screen bg-black text-white overflow-x-hidden">

      {/* Nav */}
      <nav className="border-b border-zinc-900 px-6 py-4 flex items-center justify-between max-w-7xl mx-auto">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-indigo-500 rounded-lg flex items-center justify-center">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <span className="font-bold text-lg tracking-tight">CreatorCore AI</span>
        </div>
        <div className="flex items-center gap-4">
          <span className="text-sm text-zinc-500 hidden sm:block">Trusted by 1,200+ creators</span>
          <button
            onClick={onSignUp}
            className="px-4 py-2 bg-white text-black text-sm rounded-xl font-semibold hover:bg-zinc-100 transition-colors"
          >
            Sign In
          </button>
        </div>
      </nav>

      {/* Hero */}
      <section className="max-w-4xl mx-auto px-6 pt-20 pb-16 text-center">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
          <div className="inline-flex items-center gap-2 bg-indigo-500/10 border border-indigo-500/20 rounded-full px-4 py-1.5 text-sm text-indigo-300 mb-6">
            <Zap className="w-3.5 h-3.5" />
            Now with multi-model AI routing
          </div>
          <h1 className="text-4xl md:text-6xl font-black tracking-tight mb-6 leading-tight">
            Content ideas that<br />
            <span className="text-indigo-400">actually go viral</span>
          </h1>
          <p className="text-lg text-zinc-400 max-w-2xl mx-auto mb-8">
            CreatorCore AI generates hyper-personalized content ideas, full production scripts,
            and SEO packages — automatically routed to the best AI model for your platform.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <button
              onClick={onSignUp}
              className="flex items-center justify-center gap-2 px-6 py-3.5 bg-indigo-500 hover:bg-indigo-600
                text-white font-bold rounded-xl transition-all shadow-lg shadow-indigo-500/20"
            >
              Start free — no credit card
              <ArrowRight className="w-4 h-4" />
            </button>
            <button className="px-6 py-3.5 bg-zinc-900 hover:bg-zinc-800 text-zinc-200 font-medium
              rounded-xl border border-zinc-800 transition-colors">
              See demo
            </button>
          </div>
          <p className="text-xs text-zinc-600 mt-4">3 free ideas/day. No credit card required.</p>
        </motion.div>
      </section>

      {/* Social proof numbers */}
      <section className="border-y border-zinc-900 py-10">
        <div className="max-w-4xl mx-auto px-6 grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
          {[
            { n: '1,200+', label: 'Active creators' },
            { n: '84K+', label: 'Ideas generated' },
            { n: '82/100', label: 'Avg virality score' },
            { n: '< 2.5s', label: 'Avg generation time' },
          ].map((stat) => (
            <div key={stat.label}>
              <div className="text-2xl font-black text-white">{stat.n}</div>
              <div className="text-xs text-zinc-500 mt-1">{stat.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Features */}
      <section className="max-w-6xl mx-auto px-6 py-20">
        <h2 className="text-2xl md:text-3xl font-bold text-center text-white mb-12">
          Everything you need to dominate the algorithm
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {FEATURES.map((f) => (
            <motion.div
              key={f.title}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6 hover:border-zinc-700 transition-colors"
            >
              <div className="w-10 h-10 rounded-xl bg-zinc-800 flex items-center justify-center mb-4">
                {f.icon}
              </div>
              <h3 className="font-semibold text-white mb-1.5">{f.title}</h3>
              <p className="text-sm text-zinc-400 leading-relaxed">{f.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Pricing */}
      <section className="max-w-6xl mx-auto px-6 py-16 pb-24">
        <h2 className="text-2xl md:text-3xl font-bold text-center text-white mb-3">Simple pricing</h2>
        <p className="text-zinc-500 text-center mb-12">Start free. Scale as you grow.</p>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
          {PLANS.map((plan) => (
            <div
              key={plan.name}
              className={`relative rounded-2xl p-6 border ${
                plan.highlight
                  ? 'bg-indigo-500/5 border-indigo-500/40 shadow-lg shadow-indigo-500/10'
                  : 'bg-zinc-900 border-zinc-800'
              }`}
            >
              {plan.highlight && (
                <span className="absolute -top-3 left-1/2 -translate-x-1/2 text-xs bg-indigo-500 text-white px-3 py-1 rounded-full font-semibold">
                  Most popular
                </span>
              )}
              <div className="mb-4">
                <div className="text-sm text-zinc-400 mb-1">{plan.name}</div>
                <div className="flex items-baseline gap-0.5">
                  <span className="text-2xl font-black text-white">{plan.price}</span>
                  {plan.period && <span className="text-zinc-500 text-sm">{plan.period}</span>}
                </div>
              </div>
              <ul className="space-y-2 mb-6">
                {plan.features.map((f) => (
                  <li key={f} className="flex items-center gap-2 text-sm text-zinc-300">
                    <Check className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                    {f}
                  </li>
                ))}
              </ul>
              <button
                onClick={plan.cta === 'Start free' || plan.cta === 'Start Pro' ? onSignUp : undefined}
                className={`w-full py-2.5 rounded-xl text-sm font-semibold transition-colors ${
                  plan.highlight
                    ? 'bg-indigo-500 hover:bg-indigo-600 text-white'
                    : 'bg-zinc-800 hover:bg-zinc-700 text-zinc-200 border border-zinc-700'
                }`}
              >
                {plan.cta}
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-zinc-900 px-6 py-8 text-center text-xs text-zinc-600">
        <div className="max-w-4xl mx-auto flex flex-col md:flex-row items-center justify-between gap-3">
          <span>© 2025 CreatorCore AI. All rights reserved.</span>
          <div className="flex gap-4">
            <a href="#" className="hover:text-zinc-400 transition-colors">Privacy</a>
            <a href="#" className="hover:text-zinc-400 transition-colors">Terms</a>
            <a href="#" className="hover:text-zinc-400 transition-colors">Status</a>
            <a href="#" className="hover:text-zinc-400 transition-colors">Docs</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
