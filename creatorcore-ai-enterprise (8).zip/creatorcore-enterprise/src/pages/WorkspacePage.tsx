import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import {
  Users, Plus, Mail, Shield, Eye, Pencil, Crown,
  Copy, Check, Globe, Palette, UserX, RefreshCw
} from 'lucide-react';
import { cn } from '../lib/utils';
import type { WorkspaceRole } from '../types';

// ─── Read real accounts from localStorage ─────────────────────────────────────
interface StoredAccount {
  password: string;
  user: {
    id: string;
    name: string;
    email: string;
    plan: string;
    onboardingCompleted: boolean;
  };
}

function getRealMembers(): StoredMember[] {
  try {
    const raw = localStorage.getItem('cc_accounts');
    if (!raw) return [];
    const accounts: Record<string, StoredAccount> = JSON.parse(raw);
    const session = JSON.parse(localStorage.getItem('cc_session') || '{}');
    const devUnlocked = localStorage.getItem('cc_dev_unlocked') === 'true';

    return Object.values(accounts).map((acc) => {
      const isOwner = acc.user.email === session.email;
      return {
        id: acc.user.id,
        name: acc.user.name,
        email: acc.user.email,
        plan: devUnlocked && isOwner ? 'pro' : acc.user.plan,
        role: (isOwner ? 'owner' : 'viewer') as WorkspaceRole,
        joinedAt: new Date(parseInt(acc.user.id.replace('user_', '')) || Date.now()).toLocaleDateString(),
        isYou: isOwner,
      };
    }).sort((a, b) => {
      // Owner first, then alphabetical
      if (a.isYou) return -1;
      if (b.isYou) return 1;
      return a.name.localeCompare(b.name);
    });
  } catch {
    return [];
  }
}

interface StoredMember {
  id: string;
  name: string;
  email: string;
  plan: string;
  role: WorkspaceRole;
  joinedAt: string;
  isYou: boolean;
}

const ROLE_CONFIG: Record<WorkspaceRole, { label: string; icon: React.ReactNode; color: string }> = {
  owner:  { label: 'Owner',  icon: <Crown className="w-3 h-3" />,  color: 'text-amber-400 bg-amber-900/30 border-amber-700/30' },
  admin:  { label: 'Admin',  icon: <Shield className="w-3 h-3" />, color: 'text-indigo-400 bg-indigo-900/30 border-indigo-700/30' },
  editor: { label: 'Editor', icon: <Pencil className="w-3 h-3" />, color: 'text-blue-400 bg-blue-900/30 border-blue-700/30' },
  viewer: { label: 'Viewer', icon: <Eye className="w-3 h-3" />,    color: 'text-zinc-400 bg-zinc-800 border-zinc-700' },
};

export function WorkspacePage() {
  const [inviteEmail, setInviteEmail] = useState('');
  const [inviteRole, setInviteRole] = useState<WorkspaceRole>('editor');
  const [inviteSent, setInviteSent] = useState(false);
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<'members' | 'whitelabel' | 'api'>('members');
  const [members, setMembers] = useState<StoredMember[]>([]);
  const [roleChanges, setRoleChanges] = useState<Record<string, WorkspaceRole>>({});

  const apiKey = 'cc_live_sk_••••••••••••••ab3f';

  useEffect(() => {
    setMembers(getRealMembers());
  }, []);

  const refreshMembers = () => setMembers(getRealMembers());

  const handleRoleChange = (memberId: string, newRole: WorkspaceRole) => {
    setRoleChanges((prev) => ({ ...prev, [memberId]: newRole }));
    // Persist role change to localStorage
    try {
      const raw = localStorage.getItem('cc_accounts') || '{}';
      const accounts: Record<string, StoredAccount> = JSON.parse(raw);
      const entry = Object.values(accounts).find((a) => a.user.id === memberId);
      if (entry) {
        // Store role override separately (not in account password store)
        const roles: Record<string, WorkspaceRole> = JSON.parse(localStorage.getItem('cc_member_roles') || '{}');
        roles[memberId] = newRole;
        localStorage.setItem('cc_member_roles', JSON.stringify(roles));
      }
    } catch { /* ignore */ }
  };

  const getMemberRole = (member: StoredMember): WorkspaceRole => {
    if (member.isYou) return 'owner';
    try {
      const roles: Record<string, WorkspaceRole> = JSON.parse(localStorage.getItem('cc_member_roles') || '{}');
      return roles[member.id] || roleChanges[member.id] || member.role;
    } catch {
      return member.role;
    }
  };

  const handleSendInvite = () => {
    if (!inviteEmail.trim()) return;
    setInviteSent(true);
    setInviteEmail('');
    setTimeout(() => setInviteSent(false), 3000);
  };

  const copyKey = () => {
    navigator.clipboard.writeText('cc_live_sk_demo_key_ab3f').then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  return (
    <div className="flex-1 p-4 md:p-8 overflow-y-auto pb-24 md:pb-8">
      <div className="max-w-4xl mx-auto space-y-8">

        <header>
          <h1 className="text-2xl md:text-3xl font-bold text-white tracking-tight flex items-center gap-2">
            <Users className="w-7 h-7 text-indigo-400" />
            Workspace
          </h1>
          <p className="text-zinc-400 mt-1 text-sm">
            Team collaboration, white-label settings, and API access.
          </p>
        </header>

        {/* Tabs */}
        <div className="flex gap-1 bg-zinc-900 border border-zinc-800 rounded-xl p-1 w-fit">
          {(['members', 'whitelabel', 'api'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={cn(
                'px-4 py-2 rounded-lg text-sm font-medium transition-all',
                activeTab === tab ? 'bg-zinc-800 text-white' : 'text-zinc-500 hover:text-zinc-300',
              )}
            >
              {tab === 'whitelabel' ? 'White-Label' : tab.charAt(0).toUpperCase() + tab.slice(1)}
            </button>
          ))}
        </div>

        {/* ── Members Tab ─────────────────────────────────────────────────── */}
        {activeTab === 'members' && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">

            {/* Invite */}
            <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6 space-y-4">
              <h2 className="text-base font-semibold text-white">Invite Team Member</h2>
              <div className="flex gap-3 flex-wrap">
                <input
                  type="email"
                  value={inviteEmail}
                  onChange={(e) => setInviteEmail(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSendInvite()}
                  placeholder="colleague@agency.com"
                  autoComplete="off"
                  className="flex-1 min-w-[200px] bg-black border border-zinc-800 rounded-xl px-4 py-2.5
                    text-zinc-200 text-sm focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none"
                />
                <select
                  value={inviteRole}
                  onChange={(e) => setInviteRole(e.target.value as WorkspaceRole)}
                  className="bg-black border border-zinc-800 rounded-xl px-3 py-2.5 text-zinc-300 text-sm
                    focus:ring-2 focus:ring-indigo-500 outline-none"
                >
                  <option value="viewer">Viewer</option>
                  <option value="editor">Editor</option>
                  <option value="admin">Admin</option>
                </select>
                <button
                  onClick={handleSendInvite}
                  className={cn(
                    'flex items-center gap-2 px-4 py-2.5 text-sm rounded-xl font-medium transition-colors',
                    inviteSent
                      ? 'bg-emerald-600 text-white'
                      : 'bg-indigo-500 hover:bg-indigo-600 text-white',
                  )}
                >
                  {inviteSent ? <><Check className="w-4 h-4" /> Invite Sent!</> : <><Mail className="w-4 h-4" /> Send Invite</>}
                </button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs text-zinc-500">
                <div className="flex items-center gap-2">
                  <Eye className="w-3.5 h-3.5 text-zinc-400" />
                  <span><strong className="text-zinc-300">Viewer:</strong> read-only, can't generate</span>
                </div>
                <div className="flex items-center gap-2">
                  <Pencil className="w-3.5 h-3.5 text-blue-400" />
                  <span><strong className="text-zinc-300">Editor:</strong> generate + approve ideas</span>
                </div>
                <div className="flex items-center gap-2">
                  <Shield className="w-3.5 h-3.5 text-indigo-400" />
                  <span><strong className="text-zinc-300">Admin:</strong> full access except billing</span>
                </div>
              </div>
            </div>

            {/* Real Members List */}
            <div className="bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden">
              <div className="px-6 py-4 border-b border-zinc-800 flex items-center justify-between">
                <h2 className="text-base font-semibold text-white">
                  {members.length} {members.length === 1 ? 'Member' : 'Members'}
                </h2>
                <button
                  onClick={refreshMembers}
                  className="flex items-center gap-1.5 text-xs text-zinc-500 hover:text-zinc-300 transition-colors"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  Refresh
                </button>
              </div>

              {members.length === 0 ? (
                <div className="px-6 py-12 text-center text-zinc-600 text-sm">
                  No registered users yet. Share your app URL to get members.
                </div>
              ) : (
                <div className="divide-y divide-zinc-800">
                  {members.map((member) => {
                    const role = getMemberRole(member);
                    const roleConfig = ROLE_CONFIG[role];
                    return (
                      <div key={member.id} className="flex items-center justify-between px-6 py-4 hover:bg-zinc-800/30 transition-colors">
                        <div className="flex items-center gap-3">
                          <div className={cn(
                            'w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold text-white flex-shrink-0',
                            member.isYou ? 'bg-indigo-600' : 'bg-zinc-700',
                          )}>
                            {member.name[0].toUpperCase()}
                          </div>
                          <div>
                            <div className="text-sm font-medium text-zinc-200 flex items-center gap-2">
                              {member.name}
                              {member.isYou && (
                                <span className="text-[10px] text-zinc-500 bg-zinc-800 px-1.5 py-0.5 rounded">you</span>
                              )}
                            </div>
                            <div className="text-xs text-zinc-500">{member.email}</div>
                            <div className="text-[10px] text-zinc-600 mt-0.5">
                              Joined {member.joinedAt} · {member.plan} plan
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          {/* Role — owner is fixed, others can be changed */}
                          {member.isYou ? (
                            <span className={cn('flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium border', roleConfig.color)}>
                              {roleConfig.icon}{roleConfig.label}
                            </span>
                          ) : (
                            <select
                              value={role}
                              onChange={(e) => handleRoleChange(member.id, e.target.value as WorkspaceRole)}
                              className={cn(
                                'text-xs font-medium px-2.5 py-1 rounded-full border outline-none cursor-pointer',
                                roleConfig.color,
                              )}
                            >
                              <option value="viewer">Viewer</option>
                              <option value="editor">Editor</option>
                              <option value="admin">Admin</option>
                            </select>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            <p className="text-xs text-zinc-600">
              Members list shows all accounts registered on this device. In production with Supabase auth, this would show all workspace members from the database.
            </p>
          </motion.div>
        )}

        {/* ── White-Label Tab ─────────────────────────────────────────────── */}
        {activeTab === 'whitelabel' && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
            <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6 space-y-5">
              <div className="flex items-center gap-2">
                <Palette className="w-5 h-5 text-indigo-400" />
                <h2 className="text-base font-semibold text-white">White-Label Branding</h2>
                <span className="ml-auto text-xs bg-amber-500/10 text-amber-400 border border-amber-500/20 px-2 py-0.5 rounded-full">Enterprise</span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-zinc-400 mb-1.5">Brand Name</label>
                  <input type="text" defaultValue="CreatorCore AI" autoComplete="off"
                    className="w-full bg-black border border-zinc-800 rounded-xl px-4 py-2.5 text-zinc-200 text-sm focus:ring-2 focus:ring-indigo-500 outline-none" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-zinc-400 mb-1.5">Brand Color</label>
                  <div className="flex gap-2">
                    <input type="color" defaultValue="#6366f1" className="w-10 h-10 rounded-lg bg-black border border-zinc-800 cursor-pointer p-1" />
                    <input type="text" defaultValue="#6366f1" autoComplete="off"
                      className="flex-1 bg-black border border-zinc-800 rounded-xl px-4 py-2.5 text-zinc-200 text-sm focus:ring-2 focus:ring-indigo-500 outline-none" />
                  </div>
                </div>
              </div>
              <div>
                <label className="block text-xs font-medium text-zinc-400 mb-1.5 flex items-center gap-1">
                  <Globe className="w-3.5 h-3.5" /> Custom Domain
                </label>
                <div className="flex gap-2">
                  <input type="text" placeholder="ai.youragency.com" autoComplete="off"
                    className="flex-1 bg-black border border-zinc-800 rounded-xl px-4 py-2.5 text-zinc-200 text-sm focus:ring-2 focus:ring-indigo-500 outline-none" />
                  <button className="px-4 py-2.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-sm rounded-xl border border-zinc-700 transition-colors">
                    Verify DNS
                  </button>
                </div>
                <p className="text-xs text-zinc-600 mt-1.5">
                  Add CNAME: <code className="bg-zinc-800 px-1 rounded">ai.youragency.com → app.creatorcore.ai</code>
                </p>
              </div>
              <button className="px-4 py-2.5 bg-indigo-500 hover:bg-indigo-600 text-white text-sm rounded-xl font-medium transition-colors">
                Save White-Label Settings
              </button>
            </div>
          </motion.div>
        )}

        {/* ── API Tab ─────────────────────────────────────────────────────── */}
        {activeTab === 'api' && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
            <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6 space-y-4">
              <h2 className="text-base font-semibold text-white">API Keys</h2>
              <p className="text-sm text-zinc-400">Integrate CreatorCore AI into your own tools and workflows.</p>
              <div className="bg-black border border-zinc-800 rounded-xl p-4 flex items-center gap-3">
                <code className="flex-1 text-sm text-zinc-300 font-mono">{apiKey}</code>
                <button onClick={copyKey} className="text-zinc-500 hover:text-zinc-200 transition-colors">
                  {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
              <div className="bg-zinc-800/50 rounded-xl p-4 space-y-3">
                <h3 className="text-xs font-semibold text-zinc-300 uppercase tracking-wider">Quick Start</h3>
                <pre className="text-xs text-zinc-400 overflow-x-auto whitespace-pre-wrap">{`curl -X POST https://creatorcore.ai/api/generate \\
  -H "X-Api-Key: ${apiKey}" \\
  -H "Content-Type: application/json" \\
  -d '{
    "platform": "YouTube",
    "channel": "@YourChannel",
    "description": "Tech tutorials",
    "template": "educational",
    "workspaceId": "ws_your_id"
  }'`}</pre>
              </div>
              <button className="flex items-center gap-2 px-4 py-2.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-sm rounded-xl border border-zinc-700 transition-colors">
                <Plus className="w-4 h-4" /> Create New Key
              </button>
            </div>
          </motion.div>
        )}

      </div>
    </div>
  );
}
