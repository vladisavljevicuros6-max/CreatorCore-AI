import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Loader2, Sparkles, ChevronDown, Settings2, Zap } from 'lucide-react';
import { IdeaCard } from '../components/IdeaCard';
import { generateIdeasDirect, generateScriptDirect, hasAnyApiKey, getEffectivePlan } from '../services/directGenerate';
import { cn } from '../lib/utils';
import type { GenerationBatch, GenerationRequest, Idea, AIModel, Platform, ContentStyle } from '../types';

const PLATFORMS: Platform[] = [
  'YouTube', 'YouTube Shorts', 'TikTok', 'Instagram Reels',
  'Twitter/X', 'LinkedIn', 'Twitch', 'Podcast',
];

const STYLES: { value: ContentStyle; label: string; desc: string }[] = [
  { value: 'viral', label: 'Viral', desc: 'High energy, share-triggers' },
  { value: 'educational', label: 'Educational', desc: 'Deep dives, tutorials' },
  { value: 'entertainment', label: 'Entertainment', desc: 'Story-driven, engaging' },
  { value: 'thought-leadership', label: 'Authority', desc: 'LinkedIn, credibility' },
  { value: 'balanced', label: 'Balanced', desc: 'Broad appeal' },
];

const AI_MODELS: { value: AIModel; label: string; tier?: string }[] = [
  { value: 'auto', label: '⚡ Auto (Recommended)' },
  { value: 'claude-sonnet', label: 'Claude Sonnet', tier: 'pro' },
  { value: 'gemini-pro', label: 'Gemini Pro' },
  { value: 'gpt-4o', label: 'GPT-4o' },
  { value: 'claude-haiku', label: 'Claude Haiku (Fast)' },
];

export function GeneratePage() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [batches, setBatches] = useState<GenerationBatch[]>([]);
  const [activeBatchId, setActiveBatchId] = useState<string | null>(null);
  const [scriptLoadingId, setScriptLoadingId] = useState<string | null>(null);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [lastMeta, setLastMeta] = useState<{ modelUsed: AIModel; generationMs: number } | null>(null);

  const [req, setReq] = useState<GenerationRequest>({
    platform: 'YouTube',
    channel: '',
    description: '',
    template: 'viral',
    preferredModel: 'auto',
    count: 3,
    workspaceId: 'personal',
  });

  // Load from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem('cc_batches_v2');
    if (saved) {
      try {
        const parsed = JSON.parse(saved) as GenerationBatch[];
        setBatches(parsed);
        if (parsed.length > 0) setActiveBatchId(parsed[0].id);
      } catch (e) {
        console.error('Failed to restore batches:', e);
      }
    }
  }, []);

  const saveBatches = useCallback((newBatches: GenerationBatch[]) => {
    setBatches(newBatches);
    // Limit stored batches to 20 to prevent localStorage bloat
    const toStore = newBatches.slice(0, 20);
    localStorage.setItem('cc_batches_v2', JSON.stringify(toStore));
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setLastMeta(null);

    // Guard: require API key
    if (!hasAnyApiKey()) {
      setError('No API key saved. Go to Account settings and add at least one key (Anthropic, Gemini, or OpenAI).');
      setLoading(false);
      return;
    }

    try {
      const batch = await generateIdeasDirect(req);
      setLastMeta({ modelUsed: batch.modelUsed, generationMs: batch.totalMs });
      const updated = [batch, ...batches];
      saveBatches(updated);
      setActiveBatchId(batch.id);
    } catch (err: any) {
      const msg = err.message || 'Generation failed.';
      // Make rate limit errors more user-friendly
      if (msg.includes('rate limit') || msg.includes('429') || msg.includes('Rate limit')) {
        setError('Rate limited by Gemini free tier. Wait 60 seconds and try again, or add an Anthropic/OpenAI key in Account settings as backup.');
      } else {
        setError(msg);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleGenerateScript = async (idea: Idea) => {
    setScriptLoadingId(idea.id);
    try {
      const script = await generateScriptDirect(idea);
      const updated = batches.map((b) => ({
        ...b,
        ideas: b.ideas.map((i) => (i.id === idea.id ? { ...i, script } : i)),
      }));
      saveBatches(updated);
    } catch (err: any) {
      setError(`Script failed: ${err.message}`);
    } finally {
      setScriptLoadingId(null);
    }
  };

  const handleApprove = (ideaId: string, notes: string) => {
    const updated = batches.map((b) => ({
      ...b,
      ideas: b.ideas.map((i) =>
        i.id === ideaId ? { ...i, status: 'approved' as const, curatorNotes: notes } : i
      ),
    }));
    saveBatches(updated);
  };

  const handleSchedule = (ideaId: string) => {
    const date = window.prompt('Enter date to schedule (YYYY-MM-DD):', new Date().toISOString().split('T')[0]);
    if (!date) return;
    const updated = batches.map((b) => ({
      ...b,
      ideas: b.ideas.map((i) =>
        i.id === ideaId ? { ...i, scheduledDate: date, status: 'scheduled' as const } : i
      ),
    }));
    saveBatches(updated);
  };

  const activeBatch = batches.find((b) => b.id === activeBatchId);

  return (
    <div className="flex-1 p-4 md:p-8 overflow-y-auto pb-24 md:pb-8">
      <div className="max-w-6xl mx-auto space-y-8">

        {/* Header */}
        <header className="flex flex-col md:flex-row md:items-end justify-between gap-3">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold text-white tracking-tight flex items-center gap-2">
              <Sparkles className="w-7 h-7 text-indigo-400" />
              Idea Generator
            </h1>
            <p className="text-zinc-400 mt-1 text-sm">
              Multi-model AI routing — automatically selects the best model for your platform & style.
            </p>
          </div>
          {lastMeta && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="flex items-center gap-2 text-xs text-zinc-500 bg-zinc-900 border border-zinc-800 rounded-full px-3 py-1.5"
            >
              <Zap className="w-3 h-3 text-amber-400" />
              {lastMeta.modelUsed} · {(lastMeta.generationMs / 1000).toFixed(1)}s
            </motion.div>
          )}
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Form */}
          <div className="lg:col-span-4 space-y-5">
            <form onSubmit={handleSubmit} className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6 space-y-5 shadow-xl">

              {/* Platform */}
              <div>
                <label className="block text-sm font-medium text-zinc-300 mb-2">Platform</label>
                <div className="grid grid-cols-2 gap-1.5">
                  {PLATFORMS.slice(0, 6).map((p) => (
                    <button
                      type="button"
                      key={p}
                      onClick={() => setReq({ ...req, platform: p })}
                      className={cn(
                        'px-2.5 py-1.5 rounded-lg text-xs font-medium transition-all border',
                        req.platform === p
                          ? 'bg-indigo-500 border-indigo-400 text-white'
                          : 'bg-black border-zinc-800 text-zinc-400 hover:border-zinc-600 hover:text-zinc-200',
                      )}
                    >
                      {p}
                    </button>
                  ))}
                </div>
                <select
                  value={req.platform}
                  onChange={(e) => setReq({ ...req, platform: e.target.value as Platform })}
                  className="mt-1.5 w-full bg-black border border-zinc-800 rounded-xl px-4 py-2 text-zinc-400 text-xs focus:ring-2 focus:ring-indigo-500 outline-none"
                >
                  <option value="">More platforms...</option>
                  {PLATFORMS.slice(6).map((p) => (
                    <option key={p} value={p}>{p}</option>
                  ))}
                </select>
              </div>

              {/* Channel */}
              <div>
                <label className="block text-sm font-medium text-zinc-300 mb-1.5">Channel / Brand Name</label>
                <input
                  type="text"
                  required
                  value={req.channel}
                  onChange={(e) => setReq({ ...req, channel: e.target.value })}
                  placeholder="e.g., @CoreConcept"
                  className="w-full bg-black border border-zinc-800 rounded-xl px-4 py-2.5 text-zinc-200 text-sm
                    focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all"
                />
              </div>

              {/* Description */}
              <div>
                <label className="block text-sm font-medium text-zinc-300 mb-1.5">Niche & Description</label>
                <textarea
                  required
                  rows={3}
                  value={req.description}
                  onChange={(e) => setReq({ ...req, description: e.target.value })}
                  placeholder="e.g., Science explainers with cinematic style for curious millennials."
                  className="w-full bg-black border border-zinc-800 rounded-xl px-4 py-2.5 text-zinc-200 text-sm
                    focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all resize-none"
                />
              </div>

              {/* Style */}
              <div>
                <label className="block text-sm font-medium text-zinc-300 mb-2">Content Style</label>
                <div className="grid grid-cols-1 gap-1">
                  {STYLES.map((s) => (
                    <button
                      type="button"
                      key={s.value}
                      onClick={() => setReq({ ...req, template: s.value })}
                      className={cn(
                        'flex items-center justify-between px-3 py-2 rounded-lg text-xs transition-all border text-left',
                        req.template === s.value
                          ? 'bg-indigo-500/10 border-indigo-500/40 text-indigo-300'
                          : 'bg-black border-zinc-800 text-zinc-400 hover:border-zinc-600',
                      )}
                    >
                      <span className="font-medium">{s.label}</span>
                      <span className="text-zinc-600 text-[10px]">{s.desc}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Advanced Options */}
              <div>
                <button
                  type="button"
                  onClick={() => setShowAdvanced(!showAdvanced)}
                  className="flex items-center gap-1.5 text-xs text-zinc-500 hover:text-zinc-300 transition-colors"
                >
                  <Settings2 className="w-3.5 h-3.5" />
                  Advanced options
                  <ChevronDown className={cn('w-3 h-3 transition-transform', showAdvanced && 'rotate-180')} />
                </button>
                <AnimatePresence>
                  {showAdvanced && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      className="overflow-hidden"
                    >
                      <div className="pt-3 space-y-3">
                        <div>
                          <label className="block text-xs font-medium text-zinc-400 mb-1.5">AI Model</label>
                          <select
                            value={req.preferredModel}
                            onChange={(e) => setReq({ ...req, preferredModel: e.target.value as AIModel })}
                            className="w-full bg-black border border-zinc-800 rounded-lg px-3 py-2 text-zinc-200 text-xs
                              focus:ring-2 focus:ring-indigo-500 outline-none"
                          >
                            {AI_MODELS.map((m) => (
                              <option key={m.value} value={m.value}>
                                {m.label}{m.tier ? ` (${m.tier}+)` : ''}
                              </option>
                            ))}
                          </select>
                        </div>
                        <div>
                          <label className="block text-xs font-medium text-zinc-400 mb-1.5">
                            Ideas to generate: {req.count}
                          </label>
                          <input
                            type="range"
                            min={1}
                            max={10}
                            value={req.count}
                            onChange={(e) => setReq({ ...req, count: parseInt(e.target.value) })}
                            className="w-full accent-indigo-500"
                          />
                          <div className="flex justify-between text-[10px] text-zinc-600 mt-0.5">
                            <span>1</span><span>10 (Pro)</span>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full bg-indigo-500 hover:bg-indigo-600 disabled:bg-indigo-500/40
                  text-white font-bold py-3 rounded-xl transition-all flex items-center justify-center gap-2 shadow-lg"
              >
                {loading ? (
                  <><Loader2 className="w-5 h-5 animate-spin" /> Generating...</>
                ) : (
                  <><Sparkles className="w-5 h-5" /> Generate Ideas</>
                )}
              </button>

              {error && (
                <p className="text-red-400 text-xs bg-red-400/10 p-3 rounded-lg border border-red-400/20">
                  {error}
                </p>
              )}
            </form>

            {/* History */}
            {batches.length > 0 && (
              <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-4">
                <h3 className="text-xs font-semibold text-zinc-400 mb-3 uppercase tracking-wider">History</h3>
                <div className="space-y-1 max-h-48 overflow-y-auto">
                  {batches.slice(0, 10).map((b) => (
                    <button
                      key={b.id}
                      onClick={() => setActiveBatchId(b.id)}
                      className={cn(
                        'w-full text-left px-3 py-2 rounded-lg text-xs transition-colors',
                        activeBatchId === b.id
                          ? 'bg-indigo-500/15 text-indigo-300'
                          : 'text-zinc-400 hover:bg-zinc-800 hover:text-zinc-200',
                      )}
                    >
                      <div className="font-medium truncate">{b.request.channel || 'Untitled'}</div>
                      <div className="text-zinc-600 truncate mt-0.5">
                        {b.request.platform} · {new Date(b.createdAt).toLocaleDateString()}
                        {b.modelUsed && ` · ${b.modelUsed}`}
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Results */}
          <div className="lg:col-span-8 space-y-5">
            {loading && (
              <div className="h-48 flex items-center justify-center border border-dashed border-zinc-800 rounded-2xl bg-zinc-900/20">
                <div className="flex flex-col items-center gap-3 text-zinc-400">
                  <Loader2 className="w-7 h-7 animate-spin text-indigo-500" />
                  <p className="text-sm">Routing to optimal model and generating ideas...</p>
                </div>
              </div>
            )}

            {!loading && !activeBatch && (
              <div className="h-48 flex items-center justify-center border border-dashed border-zinc-800 rounded-2xl text-zinc-600">
                Fill out the form to generate your first ideas.
              </div>
            )}

            {activeBatch && (
              <motion.div
                key={activeBatch.id}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="space-y-5"
              >
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <h2 className="text-lg font-semibold text-zinc-200">
                    {activeBatch.ideas.length} ideas for{' '}
                    <span className="text-white">{activeBatch.request.channel}</span>
                  </h2>
                  <div className="flex items-center gap-2 text-xs text-zinc-500">
                    <span className="bg-zinc-800 px-2 py-1 rounded border border-zinc-700">
                      {activeBatch.request.platform}
                    </span>
                    <span className="bg-zinc-800 px-2 py-1 rounded border border-zinc-700">
                      {activeBatch.modelUsed}
                    </span>
                  </div>
                </div>

                {activeBatch.ideas.map((idea, idx) => (
                  <IdeaCard
                    key={idea.id}
                    idea={idea}
                    index={idx}
                    onApprove={handleApprove}
                    onSchedule={handleSchedule}
                    onGenerateScript={handleGenerateScript}
                    isGeneratingScript={scriptLoadingId === idea.id}
                    showApproval
                  />
                ))}
              </motion.div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
