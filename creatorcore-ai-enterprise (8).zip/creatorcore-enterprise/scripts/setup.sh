#!/usr/bin/env bash
# ============================================================
# CreatorCore AI — First-Time Setup
# Usage: ./scripts/setup.sh
# ============================================================

set -euo pipefail

GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${BLUE}  CreatorCore AI — Setup${NC}"
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"

# Create .env.local if it doesn't exist
if [ ! -f ".env.local" ]; then
  echo -e "\n${YELLOW}Creating .env.local from template...${NC}"
  cp .env.example .env.local
  echo -e "${GREEN}✓ .env.local created — fill in your API keys${NC}"
else
  echo -e "${GREEN}✓ .env.local already exists${NC}"
fi

# Install dependencies
echo -e "\n${YELLOW}Installing dependencies...${NC}"
npm install
echo -e "${GREEN}✓ Dependencies installed${NC}"

# Check if Supabase CLI is available
if command -v supabase &> /dev/null; then
  echo -e "\n${YELLOW}Running Supabase migrations...${NC}"
  supabase db push
  echo -e "${GREEN}✓ Database migrations applied${NC}"
else
  echo -e "\n${YELLOW}⚠ Supabase CLI not found. Run migrations manually:${NC}"
  echo -e "  1. Install: npm install -g supabase"
  echo -e "  2. Run: supabase db push"
fi

# Install Vercel CLI if needed
if ! command -v vercel &> /dev/null; then
  echo -e "\n${YELLOW}Installing Vercel CLI...${NC}"
  npm install -g vercel
  echo -e "${GREEN}✓ Vercel CLI installed${NC}"
fi

# Link to Vercel project
echo -e "\n${YELLOW}Linking Vercel project...${NC}"
vercel link

echo -e "\n${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${GREEN}  ✅ Setup complete!${NC}"
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""
echo -e "  Next steps:"
echo -e "  1. Fill in API keys in ${YELLOW}.env.local${NC}"
echo -e "  2. Run ${YELLOW}npm run dev${NC} to start development"
echo -e "  3. Run ${YELLOW}./scripts/deploy.sh${NC} to deploy"
echo ""
