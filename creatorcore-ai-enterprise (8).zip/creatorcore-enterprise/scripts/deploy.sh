#!/usr/bin/env bash
# ============================================================
# CreatorCore AI — 1-Click Deploy Script
# Usage: ./scripts/deploy.sh [--preview]
# ============================================================

set -euo pipefail

RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m'

PREVIEW=${1:-""}

echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${BLUE}  CreatorCore AI — Deploy${NC}"
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"

# Check prerequisites
check_prereq() {
  if ! command -v "$1" &> /dev/null; then
    echo -e "${RED}✗ $1 not found. Please install it first.${NC}"
    exit 1
  fi
}

echo -e "\n${YELLOW}Checking prerequisites...${NC}"
check_prereq node
check_prereq npm
check_prereq vercel

echo -e "${GREEN}✓ All prerequisites met${NC}"

# Install dependencies
echo -e "\n${YELLOW}Installing dependencies...${NC}"
npm ci
echo -e "${GREEN}✓ Dependencies installed${NC}"

# Run tests
echo -e "\n${YELLOW}Running tests...${NC}"
npm run test
echo -e "${GREEN}✓ All tests passed${NC}"

# Type check
echo -e "\n${YELLOW}TypeScript check...${NC}"
npm run lint
echo -e "${GREEN}✓ TypeScript OK${NC}"

# Build
echo -e "\n${YELLOW}Building production bundle...${NC}"
npm run build
echo -e "${GREEN}✓ Build complete${NC}"

# Deploy
echo -e "\n${YELLOW}Deploying to Vercel...${NC}"
if [ "$PREVIEW" = "--preview" ]; then
  DEPLOY_URL=$(vercel deploy --yes 2>&1 | tail -1)
  echo -e "${GREEN}✓ Preview deployed: ${DEPLOY_URL}${NC}"
else
  DEPLOY_URL=$(vercel deploy --prod --yes 2>&1 | tail -1)
  echo -e "${GREEN}✓ Production deployed: ${DEPLOY_URL}${NC}"
fi

echo -e "\n${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${GREEN}  🚀 Deployment complete!${NC}"
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "  URL: ${DEPLOY_URL}"
echo ""
