-- ============================================================
-- CreatorCore AI — Supabase Database Schema
-- Migration: 001_initial
-- ============================================================

-- Enable UUID extension
create extension if not exists "pgcrypto";

-- ─── Users ────────────────────────────────────────────────────────────────────
create table if not exists public.users (
  id           uuid primary key default gen_random_uuid(),
  email        text unique not null,
  name         text not null,
  avatar_url   text,
  plan         text not null default 'free' check (plan in ('free','pro','team','enterprise')),
  onboarding_completed boolean not null default false,
  preferences  jsonb not null default '{}',
  created_at   timestamptz not null default now(),
  last_seen_at timestamptz not null default now()
);

-- ─── Workspaces ───────────────────────────────────────────────────────────────
create table if not exists public.workspaces (
  id           uuid primary key default gen_random_uuid(),
  name         text not null,
  slug         text unique not null,
  logo_url     text,
  plan         text not null default 'free',
  owner_id     uuid not null references public.users(id) on delete cascade,
  settings     jsonb not null default '{}',
  custom_domain text,
  brand_color  text,
  brand_name   text,
  created_at   timestamptz not null default now()
);

-- ─── Workspace Members ────────────────────────────────────────────────────────
create table if not exists public.workspace_members (
  id           uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  user_id      uuid not null references public.users(id) on delete cascade,
  role         text not null default 'viewer' check (role in ('owner','admin','editor','viewer')),
  joined_at    timestamptz not null default now(),
  unique(workspace_id, user_id)
);

-- ─── Generation Batches ───────────────────────────────────────────────────────
create table if not exists public.generation_batches (
  id           uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  created_by   uuid not null references public.users(id),
  request      jsonb not null,
  model_used   text not null,
  total_ms     integer,
  created_at   timestamptz not null default now()
);

-- ─── Ideas ────────────────────────────────────────────────────────────────────
create table if not exists public.ideas (
  id                  uuid primary key default gen_random_uuid(),
  batch_id            uuid not null references public.generation_batches(id) on delete cascade,
  workspace_id        uuid not null references public.workspaces(id) on delete cascade,
  created_by          uuid not null references public.users(id),
  platform            text not null,
  title               text not null,
  hook                text not null,
  explanation         text not null,
  production_tips     text not null,
  thumbnail_suggestion text not null,
  seo_title           text,
  seo_description     text,
  hashtags            text[] not null default '{}',
  virality_score      integer not null check (virality_score between 1 and 100),
  estimated_reach     bigint,
  script              text,
  thumbnail_url       text,
  scheduled_date      date,
  published_at        timestamptz,
  status              text not null default 'draft'
                      check (status in ('draft','approved','scheduled','published','archived')),
  ai_model            text not null,
  generation_ms       integer,
  curator_notes       text,
  approved_by         uuid references public.users(id),
  tags                text[] not null default '{}',
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now()
);

-- ─── API Keys ─────────────────────────────────────────────────────────────────
create table if not exists public.api_keys (
  id           uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  name         text not null,
  key_hash     text not null unique,    -- bcrypt hash
  key_preview  text not null,           -- last 4 chars
  scopes       text[] not null default '{}',
  created_at   timestamptz not null default now(),
  last_used_at timestamptz,
  revoked_at   timestamptz
);

-- ─── Usage Metrics ────────────────────────────────────────────────────────────
create table if not exists public.usage_metrics (
  id                  uuid primary key default gen_random_uuid(),
  workspace_id        uuid not null references public.workspaces(id) on delete cascade,
  period              text not null,   -- YYYY-MM
  ideas_generated     integer not null default 0,
  scripts_generated   integer not null default 0,
  models_used         jsonb not null default '{}',
  platform_breakdown  jsonb not null default '{}',
  avg_virality_score  numeric(4,1),
  avg_generation_ms   integer,
  unique(workspace_id, period)
);

-- ─── Row Level Security ───────────────────────────────────────────────────────
alter table public.users enable row level security;
alter table public.workspaces enable row level security;
alter table public.workspace_members enable row level security;
alter table public.generation_batches enable row level security;
alter table public.ideas enable row level security;
alter table public.api_keys enable row level security;

-- Users can read/update their own profile
create policy "users_self" on public.users
  using (id = auth.uid())
  with check (id = auth.uid());

-- Workspace: members can read, owners can update
create policy "workspace_members_read" on public.workspaces
  using (id in (
    select workspace_id from public.workspace_members where user_id = auth.uid()
  ));

-- Generation batches: workspace-scoped
create policy "batches_workspace" on public.generation_batches
  using (workspace_id in (
    select workspace_id from public.workspace_members where user_id = auth.uid()
  ));

-- Ideas: workspace-scoped
create policy "ideas_workspace" on public.ideas
  using (workspace_id in (
    select workspace_id from public.workspace_members where user_id = auth.uid()
  ));

-- ─── Indexes ──────────────────────────────────────────────────────────────────
create index if not exists idx_batches_workspace_id on public.generation_batches(workspace_id);
create index if not exists idx_batches_created_at on public.generation_batches(created_at desc);
create index if not exists idx_ideas_workspace_id on public.ideas(workspace_id);
create index if not exists idx_ideas_status on public.ideas(status);
create index if not exists idx_ideas_scheduled_date on public.ideas(scheduled_date);
create index if not exists idx_workspace_members_user_id on public.workspace_members(user_id);

-- ─── Updated At Trigger ───────────────────────────────────────────────────────
create or replace function public.update_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger ideas_updated_at before update on public.ideas
  for each row execute function public.update_updated_at();
